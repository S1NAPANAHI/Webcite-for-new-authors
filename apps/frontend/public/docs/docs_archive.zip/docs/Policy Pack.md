# Policy Pack (Paste-Ready Text)

All texts below are ready to paste into a CMS. They use “Sina Panahi” and zoroasterverse.com domain emails, reflect the approved decisions, and include short product-page bullets and a footer snippet.

## Copyright & Licensing

Title: Copyright & Licensing

© 2025 Sina Panahi. All rights reserved.

License

- By purchasing an ebook from Zoroasterverse, the customer receives a non-transferable, non-exclusive license to download and read for personal, non-commercial use only.
    
- Prohibited without prior written permission from the author: sharing, reselling, uploading to public repositories, or distributing the ebook in any format.
    
- Access may be suspended or revoked for policy violations or fraudulent activity.
    

Anti-Piracy and Watermarking

- Downloaded files may include a purchaser-specific watermark for security and anti-piracy purposes.
    
- We may log access activity to investigate fraud and abuse.
    

Download Limits

- Each purchase includes up to 5 downloads per format (e.g., EPUB, PDF, MOBI).
    
- If the limit is reached due to device changes or technical issues, email [support@zoroasterverse.com](mailto:support@zoroasterverse.com) with the order ID to request a reset. Reasonable requests are processed within 2–3 business days.
    

Contact

- Support: [support@zoroasterverse.com](mailto:support@zoroasterverse.com)
    
- Legal/NDA & DMCA: [legal@zoroasterverse.com](mailto:legal@zoroasterverse.com)
    
- Press/partnerships: [press@zoroasterverse.com](mailto:press@zoroasterverse.com)
    

Last updated: [Month, Year]

Product-page short bullets (for use on product pages)

- Personal-use license
    
- 5 downloads per format
    
- Watermarking for security
    
- Digital-only refund policy applies
    

—

## Refund Policy (Digital Goods)

Title: Refund Policy (Digital Goods)

Eligibility

- Refunds are available within 14 days of purchase if:
    
    - Files are defective or inaccessible; and
        
    - The item has not been meaningfully consumed (e.g., not fully downloaded/used beyond a reasonable trial).
        
- We may provide a replacement file or alternate format before issuing a refund.
    

Exclusions

- Completed downloads beyond a reasonable trial period.
    
- Non-defective files or buyer’s remorse.
    
- Issues caused by unsupported devices/apps (we will still try to help you troubleshoot).
    

How to Request

- Email [support@zoroasterverse.com](mailto:support@zoroasterverse.com) with:
    
    - Order ID
        
    - A brief description of the issue
        
    - Relevant screenshots or error messages (if any)
        
- Requests are reviewed within 2–3 business days.
    

Notes

- If a refund is granted, access to the refunded digital products may be revoked.
    
- This policy applies to digital ebooks only and does not cover future physical merchandise or print editions.
    

Last updated: [Month, Year]

—

## Reviews & Community Guidelines

Title: Reviews & Community Guidelines

Purpose

- Reviews help readers decide what to read and help the author improve. Keep feedback honest, respectful, and useful.
    

Be Constructive

- Focus on pacing, character, worldbuilding, clarity, continuity, and emotional impact.
    
- Explain what worked or didn’t, and why.
    

Spoiler Rules

- Major plot points, route outcomes, and endings must be placed inside the spoiler section.
    
- The system may auto-detect and auto-wrap spoilers if tags are missing.
    
- Use the spoiler-free template when possible; use spoiler tags when discussing major moments.
    

Respect and Relevance

- No harassment, hate speech, personal attacks, or doxxing.
    
- No spam, unrelated links, or self-promotion.
    
- Keep reviews relevant to the work and edition reviewed.
    

Moderation

- Reviews may be moderated for spoilers, abuse, spam, or policy violations.
    
- Repeat violations may result in removal of content and/or account restrictions.
    

Badges and Verification

- “Verified Purchase” badges appear when reviews are posted from accounts that own the product.
    
- Beta readers must convert their beta review into a public review on launch day to remain eligible for future cycles.
    

Reporting

- To report a review, use the in-page report function or email [support@zoroasterverse.com](mailto:support@zoroasterverse.com) with a link and reason.
    

Last updated: [Month, Year]

—

## Beta Reader Policy (Pre‑NDA Summary)

Title: Beta Reader Policy (Pre‑NDA Summary)

Overview

- The beta program provides early access to draft content in exchange for structured, timely feedback. Participation is limited and selection is merit-based.
    

Selection

- Applicants are scored on:
    
    - Availability & reliability
        
    - Analytical depth (sample feedback)
        
    - Communication tone
        
    - Genre fit (branching narratives, multi-POV)
        
    - Cohort balance (device/timezone/experience)
        
- Cohorts typically include 40–60 readers per issue.
    

Access & Reading Mode

- Hybrid access:
    
    - Watermarked file downloads for general beta drops.
        
    - Portal-only chapters for sensitive content.
        

Obligations

- Submit structured feedback by deadlines.
    
- Convert beta review to a public review on launch day (spoiler-free or spoiler-tagged template).
    
- Participate respectfully in any follow-up clarifications.
    

Confidentiality & NDA

- NDA is required prior to access.
    
- Content is confidential until public release.
    
- Leaks or sharing files externally result in immediate revocation and may trigger legal action.
    

Enforcement

- One strike (missed deadlines or failure to convert review at launch) → waitlist for the next cycle; reinstatement possible after demonstrated compliance later.
    
- Access may be revoked for policy or NDA violations.
    

Support

- Beta operations: [beta@zoroasterverse.com](mailto:beta@zoroasterverse.com) (or [support@zoroasterverse.com](mailto:support@zoroasterverse.com) if consolidated)
    
- Legal inquiries: [legal@zoroasterverse.com](mailto:legal@zoroasterverse.com)
    

Last updated: [Month, Year]

—

## Download Reset Policy

Title: Download Reset Policy

Standard Limits

- Each purchase includes up to 5 downloads per format (e.g., EPUB, PDF, MOBI).
    

When to Request a Reset

- You changed devices or reading apps multiple times.
    
- A download was interrupted or corrupted.
    
- You legitimately need additional downloads for personal use.
    

How to Request

- Email [support@zoroasterverse.com](mailto:support@zoroasterverse.com) with:
    
    - Order ID
        
    - The format(s) you need reset
        
    - A short note on why you need the reset
        
- We process reasonable requests within 2–3 business days.
    

Notes

- Excessive reset requests may be declined or investigated for abuse.
    
- Watermarking may be applied to downloaded files.
    

Last updated: [Month, Year]

—

## Footer Snippet and Product-Page Bullets

Footer legal snippet

- © 2025 Sina Panahi. All rights reserved.
    

Product-page bullets (place under purchase section)

- Personal-use license
    
- 5 downloads per format
    
- Watermarking for security
    
- Digital-only refund policy applies
    
- Recommended for ages 13+ for dark themes and narrative intensity
    

—

If any tone, phrasing, or sections should be adjusted (e.g., stronger anti-piracy language or a different reset turnaround time), specify the changes and a revised version will be provided immediately.

1. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/fa582a84-9b3e-40f5-b605-c08256d0d91f/8.-Excellent-moving-into-deliverables-production.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/fa582a84-9b3e-40f5-b605-c08256d0d91f/8.-Excellent-moving-into-deliverables-production.md)
2. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/1523de6f-0923-4bb6-82cb-ef7a201734b5/1.-Website-Blueprint-for-the-Novel-Series.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/1523de6f-0923-4bb6-82cb-ef7a201734b5/1.-Website-Blueprint-for-the-Novel-Series.md)
3. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/ab12b3d0-2a37-495b-a985-272edd9c2daa/2.-Where-We-Begin.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/ab12b3d0-2a37-495b-a985-272edd9c2daa/2.-Where-We-Begin.md)
4. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/4bc45b88-939c-4d28-b9cb-5fdd68dfe776/3.-locking-initial-decisions-and-moving-forward.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/4bc45b88-939c-4d28-b9cb-5fdd68dfe776/3.-locking-initial-decisions-and-moving-forward.md)
5. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f26d2a14-77e8-4e66-a6fd-6b74409ea4f5/4.-Locked-Decisions-What-Happens-Next2.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f26d2a14-77e8-4e66-a6fd-6b74409ea4f5/4.-Locked-Decisions-What-Happens-Next2.md)
6. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/e0a0c421-7424-4215-879a-173898b48e33/5.-setting-up-contact-age-guidance-and-next-deliverables.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/e0a0c421-7424-4215-879a-173898b48e33/5.-setting-up-contact-age-guidance-and-next-deliverables.md)
7. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f5e37101-957e-4b69-987b-1ac000dfac8e/6.-proceeding-with-deliverables.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f5e37101-957e-4b69-987b-1ac000dfac8e/6.-proceeding-with-deliverables.md)
8. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/325d0e74-6a48-4cbb-8963-c84b94c5cc90/7.-Acknowledged-proceeding-with-deliverables.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/325d0e74-6a48-4cbb-8963-c84b94c5cc90/7.-Acknowledged-proceeding-with-deliverables.md)