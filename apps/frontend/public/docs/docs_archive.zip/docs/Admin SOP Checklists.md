# Admin SOP Checklists + Microcopy Bundle (Paste‑Ready)

Below are concise, step‑by‑step SOPs for the four admin workflows, followed by the microcopy bundle for consistent UI/UX language across the site. Everything is tailored to the current decisions: watermarking for beta, 5‑download limit, spoiler modes, and the “Beta Average Score” module.

## Admin SOP Checklists

## 1) New Issue Release

Pre‑release (T−14 to T−1 days)

- Create Products
    
    - Create Standard and Deluxe editions.
        
    - Set Formats: EPUB, PDF, MOBI.
        
    - Set PreorderMonth placeholder; add ReleaseDate when finalized.
        
    - Set price, regions (no exclusions), taxes, coupons (if any).
        
- Upload Assets
    
    - Upload files; enable watermark note if applicable.
        
    - Record file sizes for Tech Specs.
        
- Product Page Copy
    
    - Paste short non‑spoiler overview.
        
    - Add Age Guidance (13+ recommended).
        
    - Add Content Warnings (editable set).
        
    - Add license bullets and 5‑download note.
        
- Beta Snapshot (if pre‑release)
    
    - Enable “Beta Average Score” module.
        
    - Confirm sample size “n” displays and has “Beta” label.
        
    - Set tooltip copy.
        
- Store Linking
    
    - Link bundle/season pages as needed.
        
    - Add preorder badge and countdown.
        
- Announcements
    
    - Draft Release Post (non‑spoiler).
        
    - Prepare newsletter segment and scheduling.
        
    - Prepare social copy (optional).
        
- QA
    
    - Verify pricing currencies and tax display.
        
    - Test page in guest vs logged‑in vs owner states.
        

Release day (T0)

- Switch preorder → release state (auto or manual).
    
- Verify purchase and download flows.
    
- Send release newsletter; publish Release Post.
    
- Monitor error logs and support inbox for the first 24h.
    

Post‑release (T+1 to T+7)

- Switch Reviews module to Public Average default.
    
- Keep “Beta Snapshot” tab accessible for transparency.
    
- Review early public reviews; moderate as needed.
    

---

## 2) Beta Cycle

Planning (T−21 to T−7)

- Set cohort target (40–60), dates for reading/review windows (2+1 weeks).
    
- Prepare application form and excerpt for feedback task.
    
- Confirm scoring weights and tie‑breakers.
    
- Prepare email templates (acceptance, waitlist, reminders, revocation, launch‑day conversion).
    

Applications (T−7 to T−1)

- Open applications; monitor completion rate.
    
- Close applications; export to scoring sheet.
    
- Apply automated scoring and rank.
    
- Enforce cohort quotas (device/timezone/experience).
    
- Build final cohort and waitlist.
    

Onboarding (T0 to T+2)

- Send Acceptance/Waitlist emails.
    
- Collect NDA e‑signatures; auto‑expire if not signed by deadline.
    
- Provision access:
    
    - Watermarked downloads.
        
    - Portal‑only chapters for sensitive drops.
        

Reading window (T+0 to T+14)

- Send mid‑window reading reminder.
    
- Monitor anomalies (excessive downloads, sharing indicators).
    

Review window (T+14 to T+21)

- Open feedback forms; send opening reminder.
    
- Send 48h‑left reminder.
    
- Track submissions; triage support issues.
    

Wrap‑up (T+21 to Launch)

- Compile feedback themes and completion metrics.
    
- Mark non‑compliant users (one strike → waitlist next cycle).
    
- Prepare launch‑day conversion campaign.
    

Launch day

- Send “Convert your beta review to public” email.
    
- Track conversion % at 24/48/72h; send nudges as needed.
    

---

## 3) Spoiler QA

Content authoring

- Tag each entry with: Arc, Issue, POV, Branch, Ending‑level, Era, SpoilerSeverity (L/M/H).
    
- Set OwnershipLocks (WorkIDs) and progress dependencies.
    

Preview sweeps

- Minimal mode:
    
    - Ensure only high‑level summaries appear; no late names or outcomes.
        
- Standard mode:
    
    - Ensure details reveal only for owned content; no leakage of unreached branches.
        
- Full mode:
    
    - Confirm complete canon is visible; route labels and endings appear correctly.
        

Spoiler lint

- Run automated lint:
    
    - Flags fields visible beyond allowed mode.
        
    - Flags cross‑links that would reveal locked content.
        
- Resolve all warnings; re‑run.
    

Page spot checks

- Character page with capsules:
    
    - Verify capsule labels and severity badges.
        
    - Verify ownership/progress locks and “Mark as finished” effects.
        
- Event page:
    
    - Check abstracted participants when locked.
        
    - Verify outcomes remain in capsules.
        

Sign‑off

- Log QA pass with date, editor initials, and any known caveats to revisit later.
    

---

## 4) Review Moderation

Intake and auto‑processing

- Auto‑wrap spoilers detected in non‑spoiler fields.
    
- Queue reasons: spoilers, abuse/hate, off‑topic/promo, spam.
    

Moderator actions

- Approve: meets guidelines; spoiler handling correct.
    
- Edit (light): redact or move a sentence into spoiler capsule; note change.
    
- Reject: clear policy breach; notify reviewer with brief rationale and link to guidelines.
    

Sorting and display

- Default sort: Helpful; allow Newest, Highest, Lowest.
    
- Filters: spoiler‑free only; route label; POV focus; edition.
    

Badges and labels

- “Verified Purchase” for public reviews when owned.
    
- “Beta” label on pre‑release reviews; move Beta tab secondary after launch.
    

Escalation

- Repeat violations → account warning; severe cases → account action per policy.
    
- Appeals: provide a simple reply channel; review within 7 days.
    

Reporting and metrics

- Weekly: approvals/rejections, top flags, response SLAs.
    
- Monthly: trends in ratings, common feedback themes, guideline gaps.
    

---

## Microcopy Bundle

General/legal

- Copyright footer: “© 2025 Sina Panahi. All rights reserved.”
    
- License bullets (product page):
    
    - “Personal‑use license”
        
    - “5 downloads per format”
        
    - “Watermarking for security”
        
    - “Digital‑only refund policy applies”
        

Age guidance and warnings

- Age guidance (standard): “Recommended for ages 13+ for dark themes and narrative intensity.”
    
- Content warnings header: “Content Warnings”
    
- Content warnings default set: “May include: violence, war consequences, psychological manipulation, moral ambiguity.”
    
- Disclaimer (small): “These warnings may contain mild spoilers.”
    

Downloads and resets

- Counter label: “Download (2/5 used)”
    
- Limit note: “Each purchase includes up to 5 downloads per format.”
    
- Reset prompt: “Need a reset? Email [support@zoroasterverse.com](mailto:support@zoroasterverse.com) (include your Order ID).”
    
- Watermark note: “Your files may include a purchaser‑specific watermark.”
    

Spoiler modes

- Global toggle label: “Spoiler Mode”
    
- Minimal: “High‑level summaries only; major reveals hidden.”
    
- Standard: “Reveals canon for content in your Library; abstracts unreached branches.”
    
- Full: “Shows all canon, including branches and endings.”
    
- Per‑page override: “Adjust for this page only”
    

Spoiler capsules

- Capsule button: “Tap to reveal”
    
- Capsule lead‑in (example): “Reveals Branch: Silent Accord — tap to reveal”
    
- Lock hint: “Unlocks after you finish: [Issue/Season]”
    
- Severity badges: “Low”, “Medium”, “High”
    

Beta program

- Beta badge (reviews): “Beta”
    
- Beta Score module title: “Beta Average Score”
    
- Beta Score tooltip: “Based on early beta feedback; may differ from public reviews.”
    
- Conversion nudge (launch‑day page banner): “Were you in the beta? Convert your review to public now.”
    

Reviews

- Form labels:
    
    - “Headline (max 80 characters)”
        
    - “Quick take (1–2 sentences)”
        
    - “Highlights (choose 2–3)”
        
    - “Rating (1–5)”
        
    - “Major Moments (spoiler capsule)”
        
    - “Route label (abstracted)”
        
- Auto‑wrap warning: “We found potential spoilers. Move them into the spoiler section?”
    
- Verified badge: “Verified Purchase”
    
- Empty state (no reviews yet): “Be the first to review this issue.”
    

Preorder and release

- Preorder badge: “Preorder: [Month, Year]”
    
- Release badge: “Available Now”
    
- Countdown label: “Releases in: [DD]d [HH]h”
    

Support and contact

- Footer contact: “Questions? Email [support@zoroasterverse.com](mailto:support@zoroasterverse.com)”
    
- Support display name: “Zoroasterverse Support”
    

---

## Handoff Notes

- Keep microcopy centralized so product and CMS share strings across pages.
    
- Localize keys early (even if English‑only at launch) to avoid rework later.
    
- Pair SOPs with checklists in the CMS or project tracker; link each step to its owner and due date.
    
- Before any publish, run Spoiler QA and Review Moderation SOPs once end‑to‑end with sample content.
    

If any labels or tone should skew more formal or more casual, specify the preference and I’ll adjust the bundle accordingly.

1. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/fa582a84-9b3e-40f5-b605-c08256d0d91f/8.-Excellent-moving-into-deliverables-production.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/fa582a84-9b3e-40f5-b605-c08256d0d91f/8.-Excellent-moving-into-deliverables-production.md)
2. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/1523de6f-0923-4bb6-82cb-ef7a201734b5/1.-Website-Blueprint-for-the-Novel-Series.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/1523de6f-0923-4bb6-82cb-ef7a201734b5/1.-Website-Blueprint-for-the-Novel-Series.md)
3. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/ab12b3d0-2a37-495b-a985-272edd9c2daa/2.-Where-We-Begin.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/ab12b3d0-2a37-495b-a985-272edd9c2daa/2.-Where-We-Begin.md)
4. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/4bc45b88-939c-4d28-b9cb-5fdd68dfe776/3.-locking-initial-decisions-and-moving-forward.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/4bc45b88-939c-4d28-b9cb-5fdd68dfe776/3.-locking-initial-decisions-and-moving-forward.md)
5. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f26d2a14-77e8-4e66-a6fd-6b74409ea4f5/4.-Locked-Decisions-What-Happens-Next2.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f26d2a14-77e8-4e66-a6fd-6b74409ea4f5/4.-Locked-Decisions-What-Happens-Next2.md)
6. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/e0a0c421-7424-4215-879a-173898b48e33/5.-setting-up-contact-age-guidance-and-next-deliverables.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/e0a0c421-7424-4215-879a-173898b48e33/5.-setting-up-contact-age-guidance-and-next-deliverables.md)
7. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f5e37101-957e-4b69-987b-1ac000dfac8e/6.-proceeding-with-deliverables.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f5e37101-957e-4b69-987b-1ac000dfac8e/6.-proceeding-with-deliverables.md)
8. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/325d0e74-6a48-4cbb-8963-c84b94c5cc90/7.-Acknowledged-proceeding-with-deliverables.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/325d0e74-6a48-4cbb-8963-c84b94c5cc90/7.-Acknowledged-proceeding-with-deliverables.md)
9. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/73989437-cf00-4de9-b15f-28f1b138d6d3/10.-Next-Steps.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/73989437-cf00-4de9-b15f-28f1b138d6d3/10.-Next-Steps.md)
10. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/819cf394-c023-4705-8aad-26ea853640ad/9.-Project-Status-Review.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/819cf394-c023-4705-8aad-26ea853640ad/9.-Project-Status-Review.md)