# Project Folder Structure (Actionable, Modular, Paste-Ready)

This breaks the entire initiative into small, ownable packages with clear boundaries. Each top-level folder mirrors a deliverable stream (policies, wireframes, beta kit, inventory, SOPs, microcopy) and includes a “_README.md” to declare scope, status, and owners. Use this as a repo or workspace root.

## Root

- /docs
    
- /blueprints
    
- /content-inventory
    
- /policies
    
- /wireframes
    
- /beta-program
    
- /reviews
    
- /spoilers
    
- /store-library
    
- /sops
    
- /microcopy
    
- /press
    
- /ops
    
- /backlog
    
- README.md
    
- PROJECT_STATUS.md
    
- CHANGELOG.md
    

---

## 1) Blueprints and Decisions

- /blueprints
    
    - /approved
        
        - website-blueprint.md
            
        - decisions-log.md
            
        - ia-taxonomy.md
            
    - /drafts
        
        - roadmap-phases.md
            
        - open-questions.md
            
    - /references
        
        - glossary-of-terms.md
            

Purpose

- Holds the canonical blueprint, IA, and locked decisions.
    
- “decisions-log.md” records approvals and reversals with dates.
    

---

## 2) Policies (Paste-ready legal)

- /policies
    
    - _README.md
        
    - copyright-and-licensing.md
        
    - refund-policy-digital-goods.md
        
    - reviews-and-community-guidelines.md
        
    - beta-reader-policy-pre-nda.md
        
    - download-reset-policy.md
        
    - cookies-and-privacy-notes.md
        
    - footer-snippets-and-product-bullets.md
        
    - /snippets
        
        - product-page-bullets.txt
            
        - footer-legal.txt
            

Purpose

- All legal texts ready for CMS copy/paste and snippet reuse.
    

---

## 3) Annotated Wireframes

- /wireframes
    
    - _README.md
        
    - /product-page
        
        - product-page-annotations.md
            
        - product-page.png
            
    - /library
        
        - library-annotations.md
            
        - library.png
            
    - /character
        
        - character-annotations.md
            
        - character.png
            
    - /event
        
        - event-annotations.md
            
        - event.png
            
    - /beta-flow
        
        - beta-application-annotations.md
            
        - nda-flow-annotations.md
            
        - beta-flow.png
            
    - /reviews
        
        - submission-annotations.md
            
        - public-listing-annotations.md
            
        - reviews.png
            

Purpose

- One folder per screen, each with a PNG/PDF and a matching annotation file.
    

---

## 4) Content Inventory (Seeded templates)

- /content-inventory
    
    - _README.md
        
    - /templates
        
        - works-and-editions.csv
            
        - characters.csv
            
        - events-and-timeline.csv
            
        - route-nodes-and-endings.csv
            
        - glossary.csv
            
        - reviews.csv
            
    - /examples
        
        - works-and-editions-seed.csv
            
        - characters-seed.csv
            
        - events-seed.csv
            
        - routes-seed.csv
            
        - glossary-seed.csv
            
        - reviews-seed.csv
            
    - /guides
        
        - tagging-and-spoiler-severity.md
            
        - ownership-locks-and-progress.md
            
        - id-conventions-and-crosslinks.md
            

Purpose

- Templates for CSV import; “guides” defines spoiler severity, ownership locks, and stable ID patterns.
    

---

## 5) Spoiler System

- /spoilers
    
    - _README.md
        
    - modes-and-defaults.md
        
    - capsules-pattern.md
        
    - authoring-checklist.md
        
    - spoiler-lint-rules.md
        
    - qa-preview-procedure.md
        
    - /labels
        
        - route-labels-placeholder.md
            
        - ending-tags.md
            

Purpose

- Centralizes spoiler behavior, QA process, labels, and lint rules.
    

---

## 6) Reviews System

- /reviews
    
    - _README.md
        
    - templates
        
        - review-template-spoiler-free.md
            
        - review-template-spoiler-tagged.md
            
    - moderation-guidelines.md
        
    - public-display-modules.md
        
    - filters-and-sorts.md
        
    - verified-purchase-rules.md
        
    - aggregates-and-beta-snapshot.md
        

Purpose

- Everything needed to collect, moderate, and display reviews.
    

---

## 7) Beta Program Kit

- /beta-program
    
    - _README.md
        
    - application-spec.md
        
    - scoring-rubric-and-weights.md
        
    - cohort-balancing-rules.md
        
    - selection-algorithm.md
        
    - operational-timeline.md
        
    - /emails
        
        - acceptance.txt
            
        - waitlist.txt
            
        - reading-reminder.txt
            
        - review-reminder.txt
            
        - revocation.txt
            
        - launchday-conversion.txt
            
    - /portal
        
        - feedback-form-spec.md
            
        - conversion-form-spec.md
            
    - anti-leak-measures.md
        
    - metrics-and-dashboards.md
        

Purpose

- End-to-end beta operations: forms, scoring, comms, timeline, and measurement.
    

---

## 8) Store & Library

- /store-library
    
    - _README.md
        
    - product-page-spec.md
        
    - edition-and-format-matrix.md
        
    - download-limits-and-counters.md
        
    - watermark-note-behavior.md
        
    - preorder-and-release-states.md
        
    - library-ux-spec.md
        
    - receipts-and-license-reminder.md
        

Purpose

- All ecommerce and library UX rules in one place.
    

---

## 9) Admin SOPs

- /sops
    
    - _README.md
        
    - new-issue-release-checklist.md
        
    - beta-cycle-checklist.md
        
    - spoiler-qa-checklist.md
        
    - review-moderation-checklist.md
        
    - /one-pagers
        
        - run-a-beta-cycle.md
            
        - score-and-select-cohort.md
            
        - handle-reminders-and-conversions.md
            
        - respond-to-breaches-revocations.md
            

Purpose

- Short, repeatable procedures, ready to run.
    

---

## 10) Microcopy

- /microcopy
    
    - _README.md
        
    - age-guidance.txt
        
    - content-warnings.txt
        
    - beta-score-tooltip.txt
        
    - download-reset-prompts.txt
        
    - spoiler-mode-labels.txt
        
    - review-form-labels.txt
        
    - library-notices.txt
        
    - preorder-and-release-text.txt
        
    - support-and-contact-lines.txt
        

Purpose

- Reusable strings for consistent UI copy across screens.
    

---

## 11) Press Kit (Optional)

- /press
    
    - _README.md
        
    - series-overview.md
        
    - author-bio.md
        
    - logo-and-covers/
        
    - feature-highlights.md
        
    - contact.md
        

Purpose

- Lightweight press assets for outreach.
    

---

## 12) Operations and Status

- /ops
    
    - _README.md
        
    - roles-and-owners.md
        
    - calendars-and-deadlines.md
        
    - risk-register.md
        
    - qa-logs/
        
        - spoiler-qa-log.md
            
        - review-moderation-log.md
            
    - decisions-register.md
        
- /backlog
    
    - _README.md
        
    - tasks/
        
        - policies-edits.md
            
        - wireframe-tweaks.md
            
        - spreadsheet-schema-changes.md
            
        - beta-weight-tuning.md
            
        - microcopy-requests.md
            

Purpose

- Who does what, when; track risks, QA results, and upcoming tasks.
    

---

## 13) Root Files

- README.md
    
    - What this repo contains and how to navigate it.
        
- PROJECT_STATUS.md
    
    - Snapshot of finalized vs in-progress items; next deliverables.
        
- CHANGELOG.md
    
    - Date-stamped changes across folders.
        

---

## Suggested Setup and Use

- Create each folder with its _README.md explaining scope, owners, and done definition.
    
- Treat /content-inventory/templates as the “source of truth” for CSV imports.
    
- Use /sops checklists during real runs; log outcomes in /ops/qa-logs.
    
- Keep microcopy centralized in /microcopy to avoid drift.
    
- Record every locked decision in /blueprints/approved/decisions-log.md and mirror key updates in PROJECT_STATUS.md.
    

If a GitHub repository is used, add issue templates for each stream (policy edit, wireframe update, beta kit change, inventory schema change, microcopy request) and wire them to the corresponding folders.

1. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f8e69b56-9f84-4f8b-8ef0-dd5f2cdb7309/Website-Blueprint-for-the-Novel-Series-No-Coding.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f8e69b56-9f84-4f8b-8ef0-dd5f2cdb7309/Website-Blueprint-for-the-Novel-Series-No-Coding.md)
2. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/efe55b34-63e9-458c-954b-ee37d718cb99/i-added-every-file-about-my-st-SVpR2RaQQu2e.HR9bigoEA.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/efe55b34-63e9-458c-954b-ee37d718cb99/i-added-every-file-about-my-st-SVpR2RaQQu2e.HR9bigoEA.md)
3. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/e69ea064-f1e4-4f80-8e6f-105c1611ef41/Comprehensive-Analysis-of-the-src-Directory-Structure-in-Full-Stack-Development-Projects.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/e69ea064-f1e4-4f80-8e6f-105c1611ef41/Comprehensive-Analysis-of-the-src-Directory-Structure-in-Full-Stack-Development-Projects.md)
4. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/6b5c4dd6-d4af-49d7-8d94-e0f0f18a36b9/i-want-to-learn-everything-the-rSCtfRaUTUOGuyxsdThGIQ.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/6b5c4dd6-d4af-49d7-8d94-e0f0f18a36b9/i-want-to-learn-everything-the-rSCtfRaUTUOGuyxsdThGIQ.md)
5. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/31eefe0f-3647-484d-81ec-59c76a1aae8a/The-Complete-Guide-to-the-src-Folder-in-Full-Sta.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/31eefe0f-3647-484d-81ec-59c76a1aae8a/The-Complete-Guide-to-the-src-Folder-in-Full-Sta.md)
6. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/9e7722e2-bb26-4fb4-8403-3f5df3c8a06f/Mastering-pages_-and-app_-Directories-in-Large.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/9e7722e2-bb26-4fb4-8403-3f5df3c8a06f/Mastering-pages_-and-app_-Directories-in-Large.md)
7. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/28a1f363-37cc-46e4-a260-03febf5c0938/Deep-Dive_-The-assets_-Directory-in-Large-Projec.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/28a1f363-37cc-46e4-a260-03febf5c0938/Deep-Dive_-The-assets_-Directory-in-Large-Projec.md)
8. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/aa0bd55d-674c-41bd-826d-81d193a973a7/Deep-Dive_-The-components_-Folder-in-Large-React.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/aa0bd55d-674c-41bd-826d-81d193a973a7/Deep-Dive_-The-components_-Folder-in-Large-React.md)
9. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/47b0bb96-9f95-48b0-bb03-7472d2fc61dd/Mastering-the-utils_-Directory-in-Large-Projects.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/47b0bb96-9f95-48b0-bb03-7472d2fc61dd/Mastering-the-utils_-Directory-in-Large-Projects.md)
10. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/3adb0770-2172-4de9-8051-6ada4e9dfbcb/today-you-will-help-me-with-my-FtAPwgR5Q9CadpwRsnERAw.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/3adb0770-2172-4de9-8051-6ada4e9dfbcb/today-you-will-help-me-with-my-FtAPwgR5Q9CadpwRsnERAw.md)
11. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/b9f36abe-b5d0-4832-b57a-375cbf590100/Phase-4.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/b9f36abe-b5d0-4832-b57a-375cbf590100/Phase-4.md)
12. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/07ae2afa-a07a-487b-91fb-5c0d6cdaa5db/Comprehensive-Guide-to-the-config_-Directory.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/07ae2afa-a07a-487b-91fb-5c0d6cdaa5db/Comprehensive-Guide-to-the-config_-Directory.md)
13. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/08fac9bb-8fc5-4e44-8d0f-a6a0fb213522/MY-WEBCITE.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/08fac9bb-8fc5-4e44-8d0f-a6a0fb213522/MY-WEBCITE.md)
14. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/8387609c-73b7-483a-a73f-3ffed7b1fadc/Phase1-Backend-Testing-Guide.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/8387609c-73b7-483a-a73f-3ffed7b1fadc/Phase1-Backend-Testing-Guide.md)
15. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/a0542efc-1e6b-4dcd-9073-3a0aba759394/Untitled-1-1.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_421871c0-953c-4207-a50d-08fcbb874978/a0542efc-1e6b-4dcd-9073-3a0aba759394/Untitled-1-1.md)