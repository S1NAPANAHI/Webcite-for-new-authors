# Content Inventory Templates (Seeded, Paste‑Ready)

Below are the six spreadsheet schemas with seeded example rows. Each sheet is designed to support spoiler controls, ownership/progress gating, and cross‑linking across the site. Copy into a spreadsheet tool (one tab per section). Field lists come first, then 3–6 sample rows to validate workflows.

## 1) Works & Editions

Fields

- WorkID (slug)
    
- Season
    
- IssueNumber
    
- Title
    
- Edition (Standard|Deluxe|Bundle)
    
- Formats (EPUB|PDF|MOBI)
    
- PreorderMonth (placeholder “[Month, Year]”)
    
- ReleaseDate (YYYY‑MM‑DD or blank)
    
- DeluxeExtras (comma‑sep; e.g., “annotations, concept art”)
    
- ContentWarnings (editable text)
    
- AgeGuidance (“13+ recommended” by default)
    
- DownloadLimit (default 5)
    
- WatermarkNote (Y/N; note shown)
    
- ProductPageCopy (short, non‑spoiler overview)
    
- StoreTags (comma‑sep)
    

Seeded rows

- S1‑I1‑STD | Season1 | 1 | The Veiled City | Standard | EPUB,PDF,MOBI | [Month, Year] | | | “violence; dark themes” | 13+ recommended | 5 | Y | “Entry point into the conflict surrounding the City’s hidden accords.” | “season1,issue1”
    
- S1‑I1‑DLX | Season1 | 1 | The Veiled City | Deluxe | EPUB,PDF,MOBI | [Month, Year] | | “annotations, concept art” | “violence; dark themes” | 13+ recommended | 5 | Y | “Includes author annotations and concept art.” | “season1,issue1,deluxe”
    
- S1‑B1 | Season1 | | Season One Bundle | Bundle | EPUB,PDF,MOBI | [Month, Year] | | “bundle bonus: mini‑artbook PDF” | “violence; dark themes” | 13+ recommended | 5 | Y | “Bundle of Season One issues with extras.” | “season1,bundle”
    

---

## 2) Characters

Fields

- CharacterID (slug)
    
- Name (public‑safe)
    
- FirstAppearanceWorkID
    
- POV (Y/N)
    
- ArcTags (comma‑sep)
    
- SpoilerSeverity (Low|Medium|High)
    
- OwnershipLocks (WorkIDs that elevate details, comma‑sep)
    
- CapsuleMinimal (short, non‑spoiler bio)
    
- CapsuleStandard (reveals canon tied to owned Works)
    
- CapsuleFull (all canon including branches/endings)
    
- Relations (CharacterIDs, abstract where needed)
    
- TimelineLinks (EventIDs, abstracted labels)
    
- BranchTags (abstract route labels; e.g., “Silent Accord”)
    

Seeded rows

- CH‑LYRA | Lyra | S1‑I1‑STD | Y | “Foundations,City” | Medium | “S1‑I1‑STD,S1‑I1‑DLX” | “An analyst drawn into the City’s fragile balance.” | “Lyra’s first mission tests loyalties as hidden accords surface.” | “Lyra’s choices diverge under Silent Accord vs Iron Vow.” | “CH‑MAREN (ally, early), CH‑ADEM (rival, hinted)” | “EV‑MARKET‑STANDOFF, EV‑HALL‑SUMMIT” | “Silent Accord, Iron Vow”
    
- CH‑MAREN | Maren | S1‑I1‑STD | N | “Foundations” | Low | “S1‑I1‑STD” | “Logistics lead with a network of favors.” | “Connects Lyra to key intermediaries.” | “Reveals leverage tactics under Veiled Tide.” | “CH‑LYRA (ally), CH‑ADEM (neutral)” | “EV‑MARKET‑STANDOFF” | “Veiled Tide”
    
- CH‑ADEM | Adem | S1‑I1‑STD | N | “City,Conflict” | High | “S1‑I1‑STD,S1‑I2‑STD” | “A figure operating at the edge of official channels.” | “His alignment varies based on early choices.” | “Ending alignment reveals in Full mode.” | “CH‑LYRA (rival), CH‑MAREN (neutral)” | “EV‑HALL‑SUMMIT” | “Iron Vow, Broken Oath”
    

---

## 3) Events / Timeline

Fields

- EventID (slug)
    
- Title (non‑spoiler safe)
    
- Era (e.g., “Foundations”)
    
- Date (in‑world, optional)
    
- Participants (CharacterIDs; abstract or initials if needed)
    
- OutcomeSummaryMinimal
    
- OutcomeSummaryStandard
    
- OutcomeSummaryFull
    
- SpoilerSeverity (Low|Medium|High)
    
- OwnershipLocks (WorkIDs)
    
- BranchTag (abstract route)
    
- RelatedWorks (WorkIDs)
    
- RelatedCharacters (CharacterIDs)
    

Seeded rows

- EV‑MARKET‑STANDOFF | Market Standoff | Foundations | 1.12 | “CH‑LYRA, CH‑MAREN” | “A tense dispute interrupts a routine supply run.” | “The dispute reveals fault lines between factions.” | “Under Silent Accord, a hidden intermediary emerges; Iron Vow escalates.” | Medium | “S1‑I1‑STD” | “Silent Accord, Iron Vow” | “S1‑I1‑STD,S1‑I1‑DLX” | “CH‑LYRA,CH‑MAREN”
    
- EV‑HALL‑SUMMIT | Hall Summit | Foundations | 1.18 | “CH‑LYRA, CH‑ADEM” | “Leaders convene to review accords.” | “A proposal challenges the status quo.” | “Full reveals branch‑dependent concessions or walk‑outs.” | High | “S1‑I1‑STD,S1‑I2‑STD” | “Veiled Tide” | “S1‑I1‑STD,S1‑I2‑STD” | “CH‑LYRA,CH‑ADEM”
    

---

## 4) Route Nodes & Endings

Fields

- NodeID (slug)
    
- NodeLabelPublic (abstract, non‑spoiler; e.g., “Gatehouse Choice”)
    
- Arc/Era
    
- Prerequisites (tags or prior nodes)
    
- BranchOptions (abstract labels, comma‑sep)
    
- SpoilerSeverity (Low|Medium|High)
    
- OwnershipLocks (WorkIDs)
    
- CapsuleMinimal (vague description)
    
- CapsuleStandard (owned‑content reveal)
    
- CapsuleFull (explicit decision dynamics)
    
- EndingID (if terminal; else blank)
    
- EndingCategory (e.g., “Reprieve”, “Severance”)
    
- EndingLabelPublic (abstract)
    

Seeded rows

- NODE‑GATE | Gatehouse Crossroads | Foundations | “Reached EV‑MARKET‑STANDOFF” | “Silent Accord, Iron Vow” | Medium | “S1‑I1‑STD” | “A choice at the threshold changes how allies respond.” | “Standard reveals who’s impacted if you own Issue1.” | “Full clarifies which path strengthens which faction.” | | |
    
- NODE‑PARLEY | Parley or Pressure | Foundations | “After NODE‑GATE” | “Veiled Tide, Broken Oath” | High | “S1‑I1‑STD,S1‑I2‑STD” | “A negotiation shifts tone.” | “Standard surfaces the cost of pressure.” | “Full names the concession or breach.” | END‑REPRIEVE | “Reprieve” | “Quiet Truce”
    
- END‑REPRIEVE | | Foundations | “After NODE‑PARLEY” | | High | “S1‑I2‑STD” | “An uneasy calm.” | “Standard hints who stands down.” | “Full details the terms and long‑tail effects.” | END‑REPRIEVE | “Reprieve” | “Quiet Truce”
    

---

## 5) Glossary

Fields

- TermID (slug)
    
- Term
    
- DefinitionMinimal (one‑line, non‑spoiler)
    
- DefinitionStandard (expanded for owners)
    
- DefinitionFull (complete, including branch‑specific nuances)
    
- ArcTags
    
- SpoilerSeverity (Low|Medium|High)
    
- OwnershipLocks (WorkIDs)
    
- RelatedEntries (Characters/Events/Nodes IDs)
    

Seeded rows

- GL‑ACCORDS | Accords | “Framework of understandings that keeps the City steady.” | “Agreements vary by faction; enforcement is informal.” | “Branch‑specific concessions emerge under Veiled Tide.” | “Foundations,City” | Medium | “S1‑I1‑STD” | “EV‑HALL‑SUMMIT,CH‑LYRA”
    
- GL‑TIDE | Veiled Tide | “A maneuvering strategy that favors leverage over force.” | “Used by intermediaries to ‘nudge’ outcomes.” | “In Full, ties to specific concessions at the Summit.” | “Foundations” | High | “S1‑I1‑STD,S1‑I2‑STD” | “EV‑HALL‑SUMMIT,NODE‑PARLEY”
    

---

## 6) Reviews

Fields

- ReviewID
    
- WorkID
    
- Edition (Standard|Deluxe|Bundle)
    
- ReviewerType (Beta|Public)
    
- VerifiedPurchase (Y/N)
    
- Headline
    
- QuickTake (1–2 sentences)
    
- Tags (choose 2–3: pacing, character, worldbuilding, clarity, emotional impact)
    
- Rating (1–5)
    
- SpoilerCapsule (text; optional)
    
- RouteLabel (abstract; optional)
    
- EndingType (abstract tag; optional, hidden unless Full or owner)
    
- HelpfulCount
    
- ReportFlags (spoilers|abuse|off‑topic)
    
- Status (Pending|Published|Rejected)
    
- SubmittedAt (UTC)
    

Seeded rows

- RV‑BETA‑001 | S1‑I1‑STD | Standard | Beta | N | “Atmospheric and tense” | “The City feels alive; the tension builds without cheap tricks.” | “pacing,worldbuilding” | 4 | | “Silent Accord” | | 5 | 0 | Published | 2025‑06‑01T12:00:00Z
    
- RV‑BETA‑002 | S1‑I1‑DLX | Deluxe | Beta | N | “Annotations add depth” | “The author notes clarified motives I missed.” | “clarity,character” | 5 | “A mid‑chapter reveal [spoiler capsule].” | “Iron Vow” | “Reprieve” | 2 | 0 | Published | 2025‑06‑02T09:00:00Z
    
- RV‑PUB‑001 | S1‑I1‑STD | Standard | Public | Y | “Hooked from chapter 2” | “Great momentum and layered politics.” | “pacing,worldbuilding” | 5 | | | | 0 | 0 | Pending | 2025‑[TBD]
    

---

## Usage Notes

- SpoilerSeverity drives capsule behavior; OwnershipLocks define when Standard content appears by default.
    
- Abstract route labels avoid raw spoilers: “Silent Accord, Iron Vow, Veiled Tide, Broken Oath” (placeholders; rename later).
    
- First pass content should prioritize Minimal capsules to keep navigation safe for new readers.
    
- For QA, preview entries in Minimal/Standard/Full before publish; fix any leakage flagged by “spoiler lint.”
    
- Keep IDs stable; titles and copy can iterate without breaking cross‑links.
    

If CSVs are preferred, say the word and I’ll output each sheet as CSV with these headers and sample rows.

1. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/fa582a84-9b3e-40f5-b605-c08256d0d91f/8.-Excellent-moving-into-deliverables-production.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/fa582a84-9b3e-40f5-b605-c08256d0d91f/8.-Excellent-moving-into-deliverables-production.md)
2. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/1523de6f-0923-4bb6-82cb-ef7a201734b5/1.-Website-Blueprint-for-the-Novel-Series.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/1523de6f-0923-4bb6-82cb-ef7a201734b5/1.-Website-Blueprint-for-the-Novel-Series.md)
3. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/ab12b3d0-2a37-495b-a985-272edd9c2daa/2.-Where-We-Begin.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/ab12b3d0-2a37-495b-a985-272edd9c2daa/2.-Where-We-Begin.md)
4. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/4bc45b88-939c-4d28-b9cb-5fdd68dfe776/3.-locking-initial-decisions-and-moving-forward.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/4bc45b88-939c-4d28-b9cb-5fdd68dfe776/3.-locking-initial-decisions-and-moving-forward.md)
5. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f26d2a14-77e8-4e66-a6fd-6b74409ea4f5/4.-Locked-Decisions-What-Happens-Next2.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f26d2a14-77e8-4e66-a6fd-6b74409ea4f5/4.-Locked-Decisions-What-Happens-Next2.md)
6. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/e0a0c421-7424-4215-879a-173898b48e33/5.-setting-up-contact-age-guidance-and-next-deliverables.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/e0a0c421-7424-4215-879a-173898b48e33/5.-setting-up-contact-age-guidance-and-next-deliverables.md)
7. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f5e37101-957e-4b69-987b-1ac000dfac8e/6.-proceeding-with-deliverables.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f5e37101-957e-4b69-987b-1ac000dfac8e/6.-proceeding-with-deliverables.md)
8. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/325d0e74-6a48-4cbb-8963-c84b94c5cc90/7.-Acknowledged-proceeding-with-deliverables.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/325d0e74-6a48-4cbb-8963-c84b94c5cc90/7.-Acknowledged-proceeding-with-deliverables.md)
9. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/73989437-cf00-4de9-b15f-28f1b138d6d3/10.-Next-Steps.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/73989437-cf00-4de9-b15f-28f1b138d6d3/10.-Next-Steps.md)
10. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/819cf394-c023-4705-8aad-26ea853640ad/9.-Project-Status-Review.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/819cf394-c023-4705-8aad-26ea853640ad/9.-Project-Status-Review.md)