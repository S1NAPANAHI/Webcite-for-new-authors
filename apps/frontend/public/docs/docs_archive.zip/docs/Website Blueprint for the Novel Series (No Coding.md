<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Website Blueprint for the Novel Series (No Coding Yet)

Below is a complete, no-code blueprint for the website—defining goals, audiences, features, workflows, content architecture, user journeys, admin needs, and a phased roadmap. The focus is on getting to 100% clarity before implementation. This is tailored for an interactive, lore-rich series with multiple POVs, branching routes, and seasonal releases, emphasizing reader engagement, ecommerce for ebooks, and a long-term content database.

## Core Goals

- Monetize the series through ebook sales, subscriptions, and special access.
- Build a living, interactive companion to the novels for tracking timelines, routes, and worldbuilding.
- Foster a community through profiles, reviews, beta programs, and newsletters.
- Maintain full control via an admin hub to manage content, users, access, and payments.


## Primary Audiences

- Casual readers: want clean navigation to buy ebooks and read news.
- Deep-lore fans: want timelines, route tracking, character indexes, maps, and wikis.
- Beta readers: want private access, NDAs, structured feedback loops.
- Press/partners: need press kit and release information.

***

## Information Architecture (Top-Level)

- Home
- Read \& Shop
    - Store (ebooks, bundles, editions, gift codes)
    - Library (purchased content, downloads, reader vault)
- The Series
    - Story Guide (reading order, branches, endings)
    - Timelines (global + POV)
    - Characters
    - Factions/Locations/Items
    - Glossary
- Interactive
    - Route Tracker
    - Lore Map
    - Timeline Explorer
    - Quizzes/Companions
- Community
    - Reviews
    - Forum/Threads (optional phase)
    - Events/AMA
- Blog \& News
    - News
    - Devlogs
    - Release Notes
- Projects
    - In Progress
    - Completed
    - Game (future web version placeholder)
- Beta Program
    - Overview
    - Application \& Evaluation
    - NDA \& Signing
    - Portal (private content, feedback, issue tracking)
- Account
    - Profile
    - Library
    - Subscriptions
    - Settings
- Admin (you)
    - Dashboard, Content, Commerce, Users, Beta, Worldbuilding, Moderation, Analytics

***

## Feature Set (By Theme)

### 1) Ecommerce \& Monetization

- Ebooks shop: single issues, seasonal bundles, deluxe editions (extras: concept art, annotations, soundtrack links).
- Pricing + promos: launch discounts, preorders, bundles, gift codes, coupon engine.
- Payments: Stripe/PayPal, local options later. VAT/tax handling based on region.
- Delivery: EPUB, PDF, MOBI; watermarking or licensed downloads; download limits; email receipts.
- Subscriptions: seasonal pass (auto-delivery per release), lore+ extras tier (behind-the-scenes, early access), founder tier (limited).
- DRM stance: permissive with watermark or harder DRM (choose strategy early).
- Refund policy: clearly defined \& automated workflows.


### 2) User Accounts \& Profiles

- Profiles: avatar, display name, bio, favorite POVs/endings, badges.
- Library: owned ebooks, download history, reading progress markers (if web reader later).
- Privacy controls: public/private shelves, review visibility toggles.
- Achievements: badges for finishing arcs, exploring timelines, completing quizzes.


### 3) Reviews \& Community

- Ratings + text reviews on issues and bundles.
- Spoiler tags + spoiler sections displayed optionally.
- Helpful/upvote signals; report abuse.
- Moderation workflow for flagged reviews.
- Rich review guidelines and examples to reduce low-signal content.


### 4) Worldbuilding Wiki (Curated, Canon-first)

- Structured entries: characters, factions, locations, items, timelines, glossary.
- Canon states: released, announced, speculative, deprecated.
- Cross-linking between entries and scenes/chapters (non-spoiler summaries + spoiler-gated content).
- Versioning: edit history, “as of Season X” diffs.
- Visual assets: maps, family trees, faction charts, artifacts.
- Search + filters: by era, POV, region, status.


### 5) Timelines \& Route Tracking

- Global timeline: macro eras, arcs, key events.
- POV timelines: character-specific sequences.
- Branching viewer: visualize decision points and alternate endings without spoilers by default.
- Route Tracker: readers mark choices they encountered; generates a personal route summary; recommends unseen branches.
- Spoiler modes: minimal/global/POV; lock advanced details unless the user has completed related content.


### 6) Blog, News, and Project Updates

- Newsroom: release posts, announcements, event recaps.
- Devlogs: behind-the-scenes, writing process, tools, art drops.
- Project board (public-facing): “Now/Next/Later/Done” view; tags by medium (prose, art, game).
- RSS + Newsletter integration.


### 7) Beta Reader Program

- Application: eligibility quiz + writing sample/past feedback experience.
- Evaluation: scoring rubric; automated shortlist.
- NDA: e-sign flow with legal name, ID verification option, auto-PDF archive and email copies.
- Portal: private builds/chapters, deadlines, feedback forms, issue threads, anonymized dashboards.
- Watermarked files + access revocation if NDA breach.
- A/B cohorting: split feedback groups to test narrative variants.
- Analytics: engagement tracking, completion rates, common feedback themes.


### 8) Newsletter \& Communications

- Segmented lists: general, buyers, beta, lore-only, events.
- Drip sequences: welcome series, release countdowns, arc recap emails.
- Triggers: purchase confirmation, new release, new wiki entries for favorited topics, route-completion badges.
- Preference center: readers choose what to receive.


### 9) Accessibility \& Localization (Plan now)

- Accessibility: semantic structure, keyboard navigation, color contrast, captions/transcripts for media.
- Localization-ready: content keys, date formats, RTL support; start with English, plan for others.


### 10) Security, Legal, and Admin

- Admin roles: owner, editor, moderator, merch manager, beta manager.
- Content governance: draft/review/publish workflow, audit logs, scheduled publishing.
- Legal: Terms, Privacy Policy, Cookie consent (GDPR/CCPA), Refund policy, NDA lifecycle.
- Age gates for mature content flags.
- Backups, export tools for data portability.

***

## Key Interactive Components (No-Code Designs)

- Reader Vault: personal dashboard showing route progress, unlocked extras, badges, and recommended next readings.
- Timeline Explorer: zoomable timeline with eras and filters; spoiler mode toggle.
- Route Visualizer: choice nodes presented as abstracted “themes” until content is unlocked; avoids raw spoilers.
- Character Index: cards with relations, affiliations, appearance timeline; spoiler-aware bio sections.
- Lore Map: interactive map (phase 2) with pins for locations, events, routes.
- Quiz Companions: “Which route did you take?” recaps that auto-tag the library and suggest endings not yet explored.

***

## Content Model (Admin Data Structures)

- Works
    - Work (Season, Issue)
    - Edition (Standard/Deluxe/Bundle)
    - Assets (EPUB/PDF/MOBI, images)
    - Release windows (preorder, release, vault unlock date)
- Worldbuilding
    - Character, Faction, Location, Item
    - Event (with date, era, participants)
    - Relationship (character↔character, faction↔location, etc.)
- Interactive
    - Node (choice point)
    - Route (sequence of nodes)
    - Ending (taggable, spoiler level)
- Community
    - Review (rating, spoiler, verified purchase)
    - Badge (criteria, icon)
- Beta
    - Cohort, Assignment, Document (NDA), Feedback Form, Issue
- Commerce
    - Product, Price, Coupon, Tax, Order, Subscription, License/Watermark

***

## User Journeys

- New visitor
    - Lands on Home → sees latest release, starter guide, “How to read branching stories” explainer → subscribes to newsletter → adds a free sample to Library → later converts to purchase.
- Owner of a Season Pass
    - Email on release → 1-click access to Library → download → route tracker suggests related wiki entries → leaves a review.
- Beta reader
    - Applies → signs NDA → gets cohort assignment → reads private chapter → submits structured feedback → receives badge.
- Deep-lore fan
    - Uses Timeline Explorer → filters by POV → adds characters to “watch” → gets notifications when relevant wiki entries update.

***

## Visual \& UI Direction

- Tone: atmospheric, legible, immersive; avoid novelty that harms readability.
- Navigation: mega-menu for The Series and Interactive; persistent Account and Cart; clear breadcrumb trails in wiki.
- Theming: dark mode default with accessible contrast; dynamic accent colors per arc/era.
- Spoiler UX: content blocks with collapsed spoiler panels; user-configurable default mode; explicit “I’ve read this” toggles.
- Cards \& Tables: use cards for characters/locations; tables for timeline events; chip filters for POV, era, branch, spoiler level.

***

## Phased Roadmap

- Phase 0: Discovery \& Legal
    - Finalize feature list, policies, NDA template, taxonomy (POV, eras, branches), data model, and content outlines.
- Phase 1: Foundation (MVP)
    - Home, Store, Checkout, Accounts, Library, Blog/News, Reviews (basic), Newsletter.
    - Worldbuilding wiki (read-only), Timelines (static), Series Guide, Admin CMS with roles.
- Phase 2: Interactivity
    - Route Tracker, Timeline Explorer (interactive), Character Index with relations, Achievements/Badges, Review moderation tools, public Projects board.
- Phase 3: Beta Program
    - Applications, automated evaluation rubric, e-sign NDAs, portal, cohorts, watermarked assets, feedback tooling.
- Phase 4: Advanced
    - Subscriptions, Lore Map, A/B narrative experiments, community forums/events, localization, web version of the game.

Each phase should ship independently and add value without breaking earlier content.

***

## Content Strategy

- Canon-first curation to avoid spoilers in navigation.
- “Start Here” guide with simple pathways for casual readers.
- Season launch kit: trailer, sample chapter, FAQ, reading order, preorder timeline.
- Devlogs and lore drops paced between releases to keep engagement.
- Community prompts: polls, “route-of-the-month,” reviewer spotlights.

***

## Admin Workflows

- Publishing a new Issue
    - Create Product → upload files → set price, taxes, regions → create Store page → write Release Post → schedule.
- Updating a Character
    - Edit base bio → add event references by date → mark spoiler sections by arc → publish change log.
- Managing Reviews
    - Queue view → auto-flagged (spoilers/abuse) → approve/edit redact spoiler tags → communicate guidelines.
- Beta cycle
    - Open applications → shortlist → send NDAs → assign builds → collect feedback → summarize themes → send thank-you badges.

***

## Open Questions to Finalize

- DRM stance: watermark vs DRM? Download limits?
- Subscription tiers: which perks per tier, and price targets?
- Scope of spoilers: what is the default level for unauthenticated vs logged-in vs owners?
- Community: forum now or later; where to host discussions first?
- Beta acceptance criteria and cohort size per release.
- Regional compliance: target countries for launch and tax readiness.
- Game web version: target engine/framework and minimum viable demo scope.

***

## Next Steps (No-Code)

- Approve or adjust the information architecture and phased roadmap.
- Decide DRM, subscriptions, spoiler policy.
- Draft NDA and review legal pages (Terms, Privacy, Refunds, Cookies).
- Start content inventory spreadsheet:
    - Works, editions, assets
    - Characters/factions/locations/events
    - Timeline entries
    - Route nodes/endings
- Define the evaluation rubric for beta readers.
- Create wireframes for:
    - Home, Store product page, Library, Story Guide
    - Timeline Explorer, Route Tracker, Character page
    - Beta Portal dashboard, Review page

When ready, we can translate this blueprint into wireframes and an implementation plan, then pick tech that supports these features with an admin-first workflow.

---

# Where We Begin: Legal, Policies, and 3 Concrete Systems (Spoilers, Subscriptions, Beta)

Below is a focused, no-code starting package: finalize legal texts, define spoiler-control mechanics, set subscription direction, and design the beta-reader selection and review pipeline. This locks the foundation before any UI or build work.

## 1) Immediate Deliverables to Approve

### A. Copyright Notice (Website + Ebook)

Use consistently across the site footer, product pages, and inside each ebook.

- Copyright Notice
    - © 2025 Sina [Last Name]. All rights reserved.
    - This ebook and its contents are protected under international copyright laws. No part of this publication may be reproduced, distributed, or transmitted in any form or by any means without prior written permission from the author.
- Licensing Terms (Non-Exclusive Personal License)
    - By purchasing this ebook, the customer is granted a non-transferable, non-exclusive license for personal use only.
    - Prohibited: sharing, reselling, uploading to public repositories, distributing in any format without explicit written permission.
    - Access may be revoked for violations or fraudulent transactions.
- Optional clauses to consider
    - Watermarking: “Each download may be watermarked with purchaser identifiers for anti-piracy purposes.”
    - Download limits: e.g., “Limit of 5 downloads per purchase; additional requests reviewed case-by-case.”
    - Refunds: “Refunds available within 14 days if the file is defective and not downloaded/used beyond a reasonable trial; otherwise at sole discretion.”

If desired, I can draft a site-wide “Copyright \& Licensing” page and a shorter product-page bullet version.

### B. Website Policies (Draft Outline)

- Terms of Service: user accounts, acceptable use, purchase terms, license scope, review rules, termination.
- Privacy Policy: data collected (accounts, purchases, reviews), cookies, analytics, email preferences, data retention, contact for data rights.
- Cookies \& Consent: list of cookies, opt-in banner, preferences manager.
- Refund Policy: eligibility, timing, digital goods handling.
- Beta NDA Policy: e-sign method, scope, confidentiality, penalties, watermarked distribution, revocation rights.

I can produce first drafts tailored to the above choices when ready.

***

## 2) Spoiler Control System (Audience-Configurable)

Design spoiler exposure as a first-class, user-controlled setting with context-aware defaults.

- Global Spoiler Modes
    - Minimal: only high-level summaries; hides names of late-appearing characters, key event outcomes, and route specifics.
    - Standard: reveals released canon for content the reader owns; abstracts future arcs and alternate endings.
    - Full: shows all canon, including branches/endings; available to owners or users who explicitly opt-in.
- Content-Based Gating
    - Ownership-aware: if a user owns Issue X, entries tied to Issue X can reveal more by default.
    - Progress toggles: “I’ve finished Season Y” toggles unlock deeper sections across wiki/timelines.
    - Spoiler capsules: each entry has spoiler blocks with labels like “Reveals Branch A resolution” and a tap-to-reveal.
- UI Controls
    - Persistent spoiler toggle in the header.
    - On first visit, a brief onboarding explaining spoiler levels with examples.
    - Per-page override: a button to elevate or reduce spoiler exposure temporarily.
- Writer/Admin Workflow
    - Each wiki/timeline node has spoiler metadata: arc, issue, branch, ending-level reveal.
    - Preview in Minimal/Standard/Full to QA leakage before publishing.

This system supports a complex, multi-route narrative and helps readers self-govern their experience.

***

## 3) Subscriptions: Direction, Not Commitment

Given a “buy-per-release” preference now, keep subscriptions optional and additive later.

- Current Model
    - Primary: per-issue purchase.
    - Bundles: seasonal bundle, deluxe editions (extras, annotations, concept art).
    - Perks for owners: enhanced spoiler unlocks, route suggestions tied to owned content.
- Future-Ready Options (No immediate launch)
    - Season Pass: prepaid access to all issues in a season; automatic library delivery.
    - Lore+ Membership: online reading access, behind-the-scenes posts, annotated chapters, exclusive polls.
    - Founders Tier (limited): name-in-credits on the website, special badge, early access to devlogs.
- Online Reader (Later)
    - Web reading experience with notes, highlights, route bookmarks, anti-piracy safeguards.
    - Syncs with the Route Tracker to personalize recommendations.

We’ll leave subscriptions dormant at launch, but design content and data models so adding them later is smooth.

***

## 4) Beta Reader Program: Selection Algorithm, Rules, and Public Reviews

A complete, enforceable funnel from application to public-facing “Rotten Tomatoes–style” reviews.

- Application Form Inputs
    - Basic: name, email, country/timezone, reading speed estimate.
    - Experience: past beta reading (titles/links), genres, strengths (plot, pacing, character, continuity).
    - Availability: weekly hours during a defined window, device formats (EPUB/PDF), consent to watermarked files.
    - Sample Feedback Task: present a short excerpt with 3 guided questions to assess clarity, specificity, and constructiveness.
    - Agreement: pre-consent to sign NDA if selected.
- Scoring Rubric (Automatable)
    - Availability \& Reliability (0–5): clear schedule, track record.
    - Analytical Depth (0–5): sample feedback demonstrates specificity and evidence.
    - Communication Tone (0–5): respectful, actionable phrasing.
    - Genre Fit (0–5): familiarity with branching narratives, multi-POV tolerance.
    - Diversity Mix (0–5): coverage across demographics, devices, and reading styles.
    - Auto-weights: e.g., Depth x1.5, Reliability x1.25, Genre Fit x1.25.
- Selection Algorithm (Outline)
    - Step 1: Filter out incomplete forms and non-consents.
    - Step 2: Normalize scores per criterion; compute weighted total.
    - Step 3: Rank candidates; then apply cohort constraints:
        - Target cohort size (e.g., 30).
        - Quotas: at least N first-time beta readers, at least M device types, balance across timezones.
    - Step 4: Tie-breakers: higher Depth, then Reliability, then demographic diversity.
    - Step 5: Generate invites → e-sign NDA → portal access.
    - Step 6: Reserve a waitlist; backfill if a reader drops.
- Participation Conditions
    - Must submit feedback by deadlines through structured forms to keep access for subsequent drops.
    - Required to submit a public review upon release:
        - Option A: spoiler-free template.
        - Option B: spoiler-marked template (auto-hidden behind spoiler tags).
    - Non-compliance: downgrade to waitlist for future cycles.
- Structured Review Templates (Displayed Publicly)
    - Spoiler-Free Template:
        - Headline (max 80 chars)
        - Quick take: 1–2 sentences
        - Highlights: pacing, characters, worldbuilding (choose 2–3 tags)
        - Content notes: tone, themes (optional)
        - Rating: 1–5
    - Spoiler-Tagged Template:
        - Everything above, plus “Major Moments” field inside spoiler capsule
        - Route path taken (select from abstracted labels, not raw spoilers)
        - Ending type: categorized tag, hidden by default
- “Tomatometer”-Style Aggregate
    - Score A: Positive ratio (≥4/5 counts “Fresh”, else “Not Fresh”).
    - Score B: Average rating.
    - Badges: “Critics’ Pick” from a curated subset (optional).
    - Filters: spoiler-free only, route, POV focus, edition (standard vs deluxe).
    - Clear legend describing how the score is calculated.
- Anti-Leak Protections
    - Watermarked files for beta.
    - Unique link-based access; device/account logging.
    - Immediate revocation upon NDA breach; auto-flag abnormal download behavior.

***

## 5) Concrete Next Steps (This Week)

- Legal and Policy Drafts
    - Approve the copyright and license text above.
    - Choose download limit and whether to watermark at launch.
    - Confirm refund posture for digital goods.
- Spoiler System Decisions
    - Approve the 3-tier spoiler modes and ownership/progress gating.
    - Decide default mode for guests vs logged-in vs owners.
    - Approve the spoiler capsules pattern for wiki/timelines.
- Beta Program Parameters
    - Choose target cohort size for the next release (e.g., 30).
    - Approve rubric weights and tie-break order.
    - Approve review templates and public scoring rules.
- Content Inventory Kickoff
    - Start the spreadsheet with these tabs:
        - Works \& Editions
        - Characters/Factions/Locations
        - Events \& Timelines (with spoiler levels)
        - Route Nodes \& Endings (with abstracted labels)
    - Define 10–15 initial entries to validate the spoiler/gating model.
- Wireframes (I can draft next)
    - Spoiler settings panel and capsule design on a Character page.
    - Beta Application form and NDA flow.
    - Review submission form (spoiler-free/spoiler-tagged) and public review listing with aggregate score.

***

## 6) Decisions to Make Now

- Watermarking: Yes/No at launch; suggested: Yes with tasteful footer ID.
- Download limit per purchase: e.g., 5; reset on request for support cases.
- Default spoiler mode for guests: Minimal; for logged-in non-owners: Minimal; for owners: Standard.
- Beta cohort size for the first cycle and minimum participation rules.
- Public score: enable “Fresh/Not Fresh” or average only.

Share preferences on the above, and I’ll draft the exact policy pages and wireframe set to match. After that, we’ll formalize the admin workflows and prepare the site structure for content entry—still without writing any code.

---

# Great—locking initial decisions and moving forward

Based on the choices:

- Watermarking: apply to beta copies; optionally require on-site reading for extra security.
- Download limit: 5 per purchase.
- Beta cohort: sizable but not too large (we’ll propose ranges below).
- Spoiler controls: adopt the global modes and ownership/progress gating.
- Reviews: display individual beta reviews and an average “beta score,” alongside public reviews post-release.

Below is what to work on next, with concrete deliverables to get to 100% clarity (still no coding).

## 1) Finalize concrete policy texts and UI copy

I’ll draft these for approval:

- Copyright \& Licensing page
    - The exact notice and personal-use license text.
    - Watermark clause.
    - Download limit policy and how resets are handled.
    - Clear, friendly anti-piracy messaging.
- Refund Policy (digital goods)
    - Conditions, time window, defect definition, process.
- Reviews \& Community Guidelines
    - What counts as constructive vs. spoilers.
    - Spoiler-tag etiquette and enforcement.
    - Consequences for abuse.
- Beta Reader Policy \& NDA Summary (pre-NDA page)
    - Eligibility, obligations, deadlines, review requirements, revocation triggers.
    - Watermarking and portal-only reading options explained clearly.
- Cookie \& Privacy notices
    - Minimal version now; expandable later.

If this direction is approved, I’ll produce the exact language for each page for review.

## 2) Beta program specs: size, cohorts, cadence, and scoring

- Cohort size options
    - Small: 20–30 (tight feedback cycles, faster moderation).
    - Medium: 40–60 (broader coverage, manageable overhead).
    - Large: 80–120 (statistically richer, heavier operations).
    - Recommendation for first cycle: 40–60. This balances diversity and overhead.
- Cohorting strategy
    - Split by device type (EPUB vs PDF), timezone, and genre familiarity.
    - Optional A/B narrative tests for branch or ending perception (Phase 3).
- Participation rules (clear and enforceable)
    - Must deliver 1 structured review per drop (spoiler-free or spoiler-tagged).
    - Must complete feedback forms by deadline.
    - Non-compliance → moved to waitlist next cycle.
- Scoring and displays
    - Individual review: 1–5 rating with tagged highlights (pacing, character, worldbuilding, etc.).
    - Beta Average Score: visible on product page during pre-release (marked “Beta”).
    - Post-release: show public reviews + maintain a “Beta Snapshot” tab for transparency.
    - “Fresh” badge rule: ≥4/5 counts as fresh; display fresh ratio and average.
- Anti-leak setup
    - Watermarked files + IP/device logging.
    - Portal-only reading option for sensitive drops.
    - Immediate revocation policy and communication template.

If you pick a cohort size and cadence (e.g., monthly or per issue), I’ll finalize the rubric weights, templates, and the public score display rules.

## 3) Spoiler system: content tagging and UI behaviors

- Tag taxonomy (assign to every lore/timeline element)
    - Arc, Issue, POV, Branch, Ending-level, Era.
    - Spoiler severity: Low/Medium/High.
    - Release-lock: ties to owned content or “I’ve finished X” toggles.
- UI defaults
    - Guests: Minimal.
    - Logged-in non-owners: Minimal.
    - Owners: Standard.
    - Per-page override toggle and on-page spoiler capsules.
- Admin workflow guardrails
    - Preview entries in all modes before publish.
    - “Spoiler lint” warnings if a field is visible beyond the user’s mode.
    - Changelog: “as of Season X” diffs on major entries.

With approval, I’ll draft example content specs for Characters, Events, and Route Nodes showing how spoiler capsules and tags appear.

## 4) Reviews system: templates, moderation, and public display

- Templates
    - Spoiler-free: headline, quick take, 2–3 tags, rating.
    - Spoiler-tagged: above + Major Moments in hidden capsule + route label.
    - Verified purchase badge for public reviews at release.
- Moderation
    - Auto-detect spoilers; auto-wrap in capsule if user forgets tag.
    - Queue with rationale (spoilers/abuse/off-topic).
    - Lightweight appeal process.
- Public display
    - Filters: spoiler-free only; route label; POV focus; edition (standard vs deluxe).
    - Sort: helpful, newest, highest, lowest.
    - Aggregate modules: Beta Average Score (pre-release), Public Average (post-release), Fresh ratio.

I can supply wireframe sketches for the review card and listing variants next.

## 5) Store and library rules to support everything

- Product packaging
    - Issue product page (editions: standard/deluxe).
    - Bundle/Season pages.
    - Preorder badge and dates.
- Delivery rules
    - 5-download limit per format; reset via support.
    - Email receipt with license reminder.
    - Optional per-file watermark at checkout.
- Library UX
    - Clear buttons: Download EPUB/PDF/MOBI.
    - “Mark as finished” toggle to unlock deeper spoilers.
    - Route suggestions based on owned/finished items.

I’ll propose the exact product page sections and library components for approval.

## 6) Content inventory: start with a small, testable slice

To validate spoiler/gating and the data model, create a short, representative set:

- Works \& Editions: 1 season, 2 issues, standard + deluxe.
- Characters: 6 key characters across 2 POVs.
- Events: 10 events across 2 eras.
- Route Nodes: 4 choice nodes with 2 endings.
- Glossary: 15 terms (with spoiler levels).
- Review seeds: 3 example beta reviews for layout testing.

I’ll provide a spreadsheet template with columns for tags, spoiler severity, ownership locks, and capsule text.

## 7) Admin workflows: finalize step-by-step procedures

- New issue release
    - Product setup → files + watermark toggle → regions/tax → schedule post → newsletter segment selection → review settings.
- Beta cycle
    - Application window → ranking → cohort assignment → NDA e-sign → first drop → deadline → reminders → review compilation.
- Spoiler QA
    - Run content lint in Minimal/Standard/Full modes → fix warnings → publish.
- Review moderation
    - Auto-flag queue → accept/redact → communicate with reviewer when necessary.

I’ll turn these into concise SOPs and checklists for repeatable execution.

## 8) Decisions to make now

- Beta cohort size for cycle 1: choose Small (20–30), Medium (40–60, recommended), or Large (80–120).
- Reading mode for beta: files with watermark, portal-only reading, or hybrid per drop.
- Pre-release public display: show “Beta Average Score” on product page? Recommended: Yes, with a “Beta” label and sample size.
- Post-release policy: require beta readers to convert their beta review into a public review on launch day (keeps continuity).
- Download reset policy: simple email support or self-serve request form.

Share choices on the above, and I’ll deliver:

- The exact legal/policy page drafts.
- The review templates and scoring rules.
- The spoiler tagging guide and example entries.
- Wireframes for: product page, library, spoiler capsules, beta application, and review listing.

Once those are approved, we’ll lock the content inventory structure and admin SOPs, then prepare a detailed implementation plan—still code-free.

<div style="text-align: center">⁂</div>

[^3_1]: Website-Blueprint-for-the-Novel-Series.md


---

# Locked Decisions + What Happens Next

Great—locking in these choices and translating them into concrete policies, UI, and workflows so nothing is ambiguous when we implement.

## Finalized Decisions

- Beta cohort size (Cycle 1): 40–60 (Medium)
- Beta reading mode: Hybrid (watermarked files + portal-only for sensitive drops)
- Pre-release display: Show “Beta Average Score” on the product page with a clear “Beta” label and sample size
- Post-release: Beta readers must convert their beta review to a public review on launch day to remain eligible for future betas
- Download reset policy: Start with simple email support (fastest to launch); add self-serve later if needed


## Policy and UI Copy (Drafts to Approve)

### A) Copyright \& Licensing (Site Footer + Product Pages + Ebook)

- © 2025 Sina [Last Name]. All rights reserved.
- Licensed for personal use only. Sharing, reselling, or distributing the ebook in any format is prohibited without explicit written permission.
- Downloads: Limited to 5 per purchase; additional resets available via support.
- Anti-piracy: Files may include a purchaser-specific watermark for security.

Short product-page bullet version:

- Personal-use license
- 5 downloads per format
- Watermarking for security
- Refunds: digital-only policy applies


### B) Refund Policy (Digital Goods)

- Eligibility: Refunds within 14 days if files are defective or inaccessible and the item has not been meaningfully consumed.
- Exclusions: Non-defective files, completed downloads beyond reasonable trial, or buyer’s remorse are not refundable.
- Process: Contact support with order ID and a brief description; resolutions include replacement file or refund at our discretion.


### C) Reviews \& Community Guidelines

- Be constructive: address pacing, character, worldbuilding, clarity, continuity.
- Use spoiler tags: major plot points must be placed in the spoiler section; the system may auto-wrap detected spoilers.
- Respect and relevance: no harassment, off-topic, or promotional content.
- Violations may result in content removal and account action.


### D) Beta Reader Policy (Pre-NDA Summary)

- Selection: Applicants are scored on availability, analytic depth, tone, genre fit, and cohort balance.
- Obligations: Submit structured feedback by deadlines; convert beta review to public review on launch day.
- Access: Hybrid reading—watermarked downloads and portal-only chapters for sensitive materials.
- Confidentiality: NDA required; leaks trigger immediate revocation and possible legal action.
- Continuity: Non-compliance moves a reader to the waitlist for future cycles.


### E) Download Reset Policy

- If the 5-download limit is reached, email support with order ID; we’ll reset reasonable cases within 2–3 business days.
- Future: a self-serve reset request form may be added.


## Beta Program: Operational Specs

- Cohort: 40–60 readers, split across device types, timezones, and genre familiarity.
- Cadence: Per-issue cycle; portal drops may be staggered A/B when testing narrative variants.
- Reviews:
    - Individual beta reviews use the structured template.
    - Product page shows “Beta Average Score” with sample size, labeled “Beta.”
    - On launch day, beta readers publish their public review version (spoiler-free or spoiler-tagged).
- Enforcement:
    - Missed feedback or failure to convert to public review → loss of priority in next cycle.
    - Reinstatement possible after one cycle with demonstrated compliance.


## Spoiler System: Implementation Details

- Default modes:
    - Guests: Minimal
    - Logged-in non-owners: Minimal
    - Owners: Standard
- Per-page toggle + global header toggle.
- Ownership/progress gating: “I’ve finished Issue/Season X” unlocks deeper sections.
- Authoring:
    - Each entry marked with Arc, Issue, POV, Branch, Ending-level, Severity(L/M/H).
    - Pre-publish preview in all modes; spoiler lint warns about leaks.
- Display:
    - Spoiler capsules with clear labels (e.g., “Reveals Branch A outcome”).
    - Route labels abstracted (“Mercy Path”, “Silent Accord”) to avoid raw spoilers in public.


## Reviews: Templates and Display

- Spoiler-free template:
    - Headline
    - Quick take (1–2 sentences)
    - Highlights (choose tags: pacing, character, worldbuilding, clarity, emotional impact)
    - Content notes (optional)
    - Rating (1–5)
- Spoiler-tagged template:
    - All of the above + “Major Moments” in a spoiler capsule
    - Route label (abstracted)
    - Ending type tag (hidden unless Full mode or owner)
- Public listing:
    - Filters: spoiler-free only; route label; POV focus; edition (standard/deluxe)
    - Sort: Helpful, Newest, Highest, Lowest
    - Aggregates:
        - Pre-release: Beta Average Score (labelled “Beta,” with n=sample size)
        - Post-release: Public Average + Fresh ratio (≥4/5 counts as “Fresh”)


## Store \& Library: Rules to Support the Above

- Product pages:
    - Key: Editions, formats, download limits, watermark note, refund note, Beta Average Score (pre-release)
    - Preorder states and dates; bundle/season links
- Library:
    - Download buttons per format with counter (e.g., 2/5 used)
    - Mark-as-finished toggle to unlock spoilers
    - Route suggestions connected to owned/finished items


## Immediate To-Dos For This Week

- Confirm last name for legal text.
- Approve the above policy/UI copy drafts or request edits.
- Choose beta cadence for Cycle 1 (per issue; suggested: 2-week window for reading + 1-week for reviews).
- Approve enforcement stance (one strike = waitlist next cycle).
- Greenlight the review templates and Beta Average Score module.

Once confirmed, I will deliver:

- Finalized policy pages (Terms excerpt, Privacy excerpt, Refund, Reviews, Beta Policy).
- Wireframes for:
    - Product page with “Beta Average Score”
    - Library with download counters and spoiler unlock
    - Spoiler capsule patterns on Character/Event pages
    - Beta application + NDA flow
    - Review submission and public listing

Would it be acceptable to proceed with:

- Cohort cadence: 2+1 weeks per issue, as suggested
- Enforcement: one strike → waitlist next cycle
- Use “Sina [Last Name]” in all legal copy once provided

If yes, I’ll finalize the texts and wireframes next.

<div style="text-align: center">⁂</div>

[^4_1]: Website-Blueprint-for-the-Novel-Series.md


---

# Excellent — Approvals Recorded. Here’s What You Get Next

All confirmations are locked:

- Legal/UI copy: approved with “Sina Panahi.”
- Beta cadence: 2 weeks reading + 1 week reviews (per issue).
- Enforcement: one strike → waitlist next cycle.
- Reviews: templates approved; “Beta Average Score” module greenlit.

Below are the concrete deliverables I’ll prepare next, plus what I need from you to keep momentum.

## 1) Final Policy Pages (ready for paste into CMS)

I will deliver clean, production-ready text blocks for:

- Copyright \& Licensing (site page + short product-page bullets)
- Refunds (digital goods)
- Reviews \& Community Guidelines
- Beta Reader Policy (pre-NDA summary)
- Download Reset Policy
- Footer snippets for: © 2025 Sina Panahi. All rights reserved.

Note: I’ll also include meta descriptions and concise “TL;DR” summaries for each page to use in footers/tooltips.

## 2) Wireframes Package (no-code)

I’ll produce low-fidelity wireframes showing layout, copy placement, and interactions for:

- Product Page (with “Beta Average Score” + sample size, preorder state, editions, formats, download policy)
- Library (download counters 0/5 per format, watermark note, “Mark as finished” spoiler unlock)
- Spoiler Capsules + Page Toggle (Character page and Event page examples)
- Beta Application → NDA Flow (scored fields, consent, e-sign checkpoint, confirmation)
- Review Submission (spoiler-free and spoiler-tagged templates) + Public Review Listing (filters, aggregations)

Deliverable format: annotated PDFs or images with component callouts and microcopy. If preferred, I can mirror them to a Figma file later.

## 3) Beta Program Kit

You’ll receive:

- Application Form Specification (all fields, validation rules, weights)
- Scoring Rubric (weights, normalization, tie-breakers)
- Cohort Assignment Rules (device/timezone/experience balance)
- Communication Templates:
    - Acceptance email (with e-sign link and timing)
    - Waitlist email
    - Reminder emails (reading period and review deadline)
    - Revocation notice (in case of NDA breach or non-compliance)
- Review Conversion Reminder (launch-day automation copy)


## 4) Content Inventory Spreadsheet Templates

I’ll provide structured sheets with ready-to-use columns:

- Works \& Editions: title, issue, season, formats, preorder/release dates, edition notes
- Characters: arc, POV, first-appearance issue, spoiler severity, capsule text (min/standard/full)
- Events \& Timeline: era, date, participants, spoiler severity, ownership locks
- Route Nodes \& Endings: abstracted labels, branches, conditions, spoiler level
- Glossary: term, arc, spoiler severity, cross-links
- Reviews: fields matching templates, moderation flags, visibility state

These templates will be pre-filled with 2–3 example rows to demonstrate correct tagging and spoiler gating.

## 5) Admin SOPs (Checklists)

Short, repeatable checklists for:

- New Issue Release (product setup → watermark toggle → preorder → newsletter segment → review settings → schedule)
- Beta Cycle (open → score → assign → NDA → drop → reminders → compile → enforce)
- Spoiler QA (preview in Minimal/Standard/Full; fix lint warnings)
- Review Moderation (auto-wrap spoilers → approval queue → communication workflow)


## 6) Public-Facing Microcopy and Labels

Clear, concise UI text for:

- “Beta Average Score” badge + tooltip (“Based on early beta feedback, may differ from public reviews.”)
- Download counters (“2/5 downloads used — Need a reset? Contact support.”)
- Spoiler modes (Minimal, Standard, Full) with 1-line descriptors
- Review forms (field prompts and helper text)
- Library notices (watermark disclosure)


## 7) Optional: Press Kit Outline

A basic press kit structure to support outreach at launch:

- Series overview (1 paragraph)
- Author bio + headshot
- Covers and logo pack
- Feature highlights (interactive timeline, route tracker)
- Contact info

***

## Decisions/Inputs Needed From You

- Support email to list in policies (e.g., support@domain.com).
- If there are mature-content elements, confirm whether to include an 18+ content flag and age gate.
- Any preferred abstract route labels to seed (e.g., “Silent Accord,” “Iron Vow,” etc.), or I’ll propose a starter set.
- Preorder timeline for the first issue (rough month is enough for now).
- Any regions to exclude at launch (for tax simplicity).

***

## Delivery Plan and Order

- Day 1–2: Policy pages + microcopy + email templates.
- Day 2–3: Wireframes (Product, Library, Spoiler Capsules, Beta Flow, Reviews).
- Day 3: Inventory spreadsheets + Admin SOPs.

Once those are approved, we’ll:

- Validate the spoiler system using the example entries.
- Confirm the beta scoring weights with a dry run on 3–5 mock applications.
- Lock the IA for the MVP and prepare the implementation plan (still no code).

If the above schedule works, I’ll start drafting with “Sina Panahi” in all legal copy and use a placeholder support email unless provided.

<div style="text-align: center">⁂</div>

[^5_1]: 4.-Locked-Decisions-What-Happens-Next2.md

[^5_2]: 1.-Website-Blueprint-for-the-Novel-Series.md

[^5_3]: 2.-Where-We-Begin.md

[^5_4]: 3.-locking-initial-decisions-and-moving-forward.md


---

# Noted — setting up contact, age guidance, and next deliverables

Thanks for the inputs. I’ll incorporate the following and proceed.

## Contact and Support

- Domain-based emails to use:
    - support@zoroasterverse.com — primary customer support (listed in policies and receipts)
    - legal@zoroasterverse.com — NDA, DMCA, and policy inquiries
    - press@zoroasterverse.com — media/partners
    - beta@zoroasterverse.com — beta program operations (optional; can alias to support early on)

If email isn’t ready yet, I’ll still place these in the drafts with a “pending setup” note so replacing is a single edit later.

## Age Guidance

- No adult content; tone is dark. Recommended gating:
    - Audience guidance: “13+ recommended” with thematic warnings (violence, dark themes).
    - Optionally: raise to 16+ if desired on product pages and wiki entries with heavier themes.
- Implementation:
    - Add “Content Warnings” section on product pages and relevant wiki entries.
    - No age gate required; include a simple disclaimer in the footer and policies.


## Route Labels

- Understood—no labels yet. I’ll propose a neutral starter set that avoids spoilers and can be replaced later:
    - Silent Accord
    - Iron Vow
    - Ember Path
    - Veiled Tide
    - Broken Oath
    - Glass Crown
    - Pale Lantern
    - Thorn Pact

These are placeholders to demonstrate UI and spoiler handling only.

## Preorder Timeline

- Will assume “Preorder: [Month, Year]” placeholder for the first issue in product/wireframe text, editable later.
- Product page sections will support “Preorder” state, countdown, and auto-switch to “Release” on date.


## Regions

- No exclusions at launch. I’ll reflect this in policies and store notes and keep the tax note generic.

***

## What I’ll deliver next

- Final policy pages using “Sina Panahi” and zoroasterverse.com emails:
    - Copyright \& Licensing
    - Refunds (digital goods)
    - Reviews \& Community Guidelines
    - Beta Reader Policy (pre-NDA summary)
    - Download Reset Policy
    - Footer/legal snippets (© 2025 Sina Panahi. All rights reserved.)
- Wireframes (annotated) with placeholder preorder month and route labels:
    - Product Page (with “Beta Average Score” + sample size and preorder state)
    - Library (download counters 0/5, watermark note, “Mark as finished” spoiler unlock)
    - Character/Event pages (spoiler capsules + global/per-page spoiler toggles)
    - Beta Application → NDA Flow (scored fields, consent, e-sign checkpoint)
    - Review Submission + Public Listing (filters, aggregates)
- Beta Program Kit:
    - Application spec, scoring rubric/weights, cohort assignment rules
    - Email templates (acceptance, waitlist, reminders, revocation)
    - Launch-day “convert to public review” reminder
- Content Inventory Templates:
    - Works/Editions, Characters, Events/Timeline, Route Nodes/Endings, Glossary, Reviews
    - Seeded with example rows and placeholder route labels
- Admin SOP Checklists:
    - New Issue Release, Beta Cycle, Spoiler QA, Review Moderation

***

## Quick confirmations to keep moving

- Use “13+ recommended” as the default audience guidance with content warnings on relevant pages? If preferred, I can set “16+ recommended.”
- Proceed with the placeholder route labels above and a placeholder preorder month?
- Default support email: support@zoroasterverse.com for now, with legal@/press@ as secondary?

If that all sounds good, I’ll produce the policy texts and wireframes next.

<div style="text-align: center">⁂</div>

[^6_1]: 4.-Locked-Decisions-What-Happens-Next2.md

[^6_2]: 1.-Website-Blueprint-for-the-Novel-Series.md

[^6_3]: 2.-Where-We-Begin.md

[^6_4]: 3.-locking-initial-decisions-and-moving-forward.md


---

# Confirmed — using 13+ guidance and proceeding

Acknowledged:

- Audience guidance: 13+ recommended (with thematic content warnings).
- Proceed with placeholder route labels and preorder month.
- Use domain emails: support@zoroasterverse.com (primary), plus legal@, press@, beta@ as needed.

Here’s what will be delivered next and what will be needed to finalize.

## Coming Deliverables (no-code)

1) Final policy texts (ready to paste into CMS)

- Copyright \& Licensing page and short product-page bullets
- Refund Policy (digital goods)
- Reviews \& Community Guidelines
- Beta Reader Policy (pre-NDA summary)
- Download Reset Policy
- Footer legal snippets: © 2025 Sina Panahi. All rights reserved.

2) Annotated wireframes

- Product Page: preorder state, editions/formats, “Beta Average Score” with sample size, content warnings, license bullets, download-limit note.
- Library: format buttons with 0/5 counters, watermark note, “Mark as finished” unlock, route suggestions.
- Character/Event page: spoiler capsules, global header toggle, per-page override.
- Beta Application → NDA flow: scored fields, consent, e-sign checkpoint, confirmation.
- Review submission + public listing: spoiler-free/tagged templates, filters, helpfulness, aggregates.

3) Beta Program Kit

- Application form spec and validation rules
- Scoring rubric (weights, tie-breakers), cohort balancing rules
- Email templates: acceptance, waitlist, reminder, revocation, launch-day “convert to public review”
- Public “Beta Average Score” module copy and placement

4) Content inventory spreadsheets (seeded)

- Works \& Editions, Characters, Events/Timeline, Route Nodes/Endings, Glossary, Reviews
- Columns pre-configured for spoiler levels, ownership locks, and capsule text

5) Admin SOPs (checklists)

- New Issue Release, Beta Cycle, Spoiler QA, Review Moderation


## Small inputs needed before finalizing copy

- Support email display name: “Zoroasterverse Support” ok?
- Content warnings: list 3–5 expected themes to display consistently (e.g., violence, grief, manipulation, war, cult activity). If none provided, I’ll draft a neutral starter set you can edit.


## Proposed microcopy for age guidance and warnings

- Age guidance line for product pages and wiki:
    - “Recommended for ages 13+ for dark themes and narrative intensity.”
- Content warnings block (example; editable later):
    - “May include: violence, war consequences, psychological manipulation, moral ambiguity.”

If this looks good, I’ll finalize the texts and wireframes with:

- support@zoroasterverse.com as the visible contact
- 13+ recommended notices and editable content warnings
- Placeholder preorder month and abstract route labels

Next message from me will include:

- The full policy page texts
- Wireframe set (annotated)
- Spreadsheet templates (download-ready descriptions)
- Beta Kit specs and email templates

Ready to proceed on that basis.

<div style="text-align: center">⁂</div>

[^7_1]: 4.-Locked-Decisions-What-Happens-Next2.md

[^7_2]: 1.-Website-Blueprint-for-the-Novel-Series.md

[^7_3]: 2.-Where-We-Begin.md

[^7_4]: 3.-locking-initial-decisions-and-moving-forward.md


---

# Perfect — proceeding with deliverables

All confirmations are locked. Work now shifts to drafting the final policy texts, annotated wireframes, beta kit, inventory templates, admin SOPs, and microcopy. Below is the delivery checklist and what will arrive first.

## What I’ll deliver next (in this order)

1) Final policy texts (ready to paste into CMS)

- Copyright \& Licensing (with © 2025 Sina Panahi, personal-use license, watermark clause, 5-download limit, anti-piracy note)
- Refund Policy (digital goods)
- Reviews \& Community Guidelines
- Beta Reader Policy (pre-NDA summary)
- Download Reset Policy
- Footer/legal snippets and short product-page bullets
- Contact emails: support@zoroasterverse.com (primary), legal@, press@, beta@

2) Annotated wireframes (no-code, low-fidelity)

- Product Page: preorder state, editions/formats, content warnings (13+), “Beta Average Score” with sample size, license bullets, download limit
- Library: per-format download buttons with counters (0/5), watermark note, “Mark as finished” spoiler unlock, route suggestions
- Character/Event pages: spoiler capsules, global spoiler toggle, per-page override
- Beta Application → NDA flow: scored fields, validation, consent, e-sign checkpoint, confirmation screen
- Review Submission (spoiler-free/tagged) + Public Listing (filters, sort, aggregates, helpfulness)

3) Beta Program Kit

- Application form spec with validation and scoring weights
- Cohort balancing rules (device, timezone, experience)
- Email templates: acceptance, waitlist, reminders, revocation, launch-day “convert to public review”
- Public-facing “Beta Average Score” module copy and tooltip

4) Content inventory spreadsheet templates (seeded)

- Works \& Editions, Characters, Events/Timeline, Route Nodes/Endings, Glossary, Reviews
- Columns preconfigured for spoiler levels, ownership locks, arc/issue/branch tags, and capsule text
- Placeholder preorder month and abstract route labels included

5) Admin SOP checklists

- New Issue Release
- Beta Cycle
- Spoiler QA
- Review Moderation

6) Microcopy set

- Age guidance: “Recommended for ages 13+ for dark themes and narrative intensity.”
- Content warnings (editable): “May include: violence, war consequences, psychological manipulation, moral ambiguity.”
- Beta Score tooltip: “Based on early beta feedback; may differ from public reviews.”
- Download counter prompts and support reset wording
- Spoiler mode labels and descriptions


## Timeline

- Policies + microcopy: next
- Wireframes: right after policies
- Inventory templates + Beta Kit + SOPs: immediately following wireframes

No coding will be done—only deliverables for approval. After you review and sign off, we’ll lock the IA for MVP and outline the implementation plan.

<div style="text-align: center">⁂</div>

[^8_1]: 4.-Locked-Decisions-What-Happens-Next2.md

[^8_2]: 1.-Website-Blueprint-for-the-Novel-Series.md

[^8_3]: 2.-Where-We-Begin.md

[^8_4]: 3.-locking-initial-decisions-and-moving-forward.md


---

# Acknowledged — proceeding with deliverables

Approvals are recorded. Work now shifts to drafting final policy texts, annotated wireframes, the beta kit, content-inventory templates, admin SOPs, and microcopy (no code). Below are the first deliverables for review.

## 1) Final Policy Texts (paste-ready)

### A) Copyright \& Licensing

- © 2025 Sina Panahi. All rights reserved.
- License
    - By purchasing an ebook from Zoroasterverse, the customer receives a non-transferable, non-exclusive license to download and read for personal, non-commercial use only.
    - Prohibited without prior written permission: sharing, reselling, uploading to public repositories, or distributing the ebook in any format.
- Anti-piracy and Watermarking
    - Downloaded files may include a purchaser-specific watermark for security and anti-piracy purposes.
- Download Limits
    - Each purchase includes up to 5 downloads per format (e.g., EPUB, PDF, MOBI).
    - If the limit is reached, contact support@zoroasterverse.com with the order ID to request a reset. Reasonable cases are processed within 2–3 business days.
- Contact
    - Support: support@zoroasterverse.com
    - Legal and NDA: legal@zoroasterverse.com
    - Press and partnerships: press@zoroasterverse.com

Short product-page bullets:

- Personal-use license
- 5 downloads per format
- Watermarking for security
- Digital-only refund policy applies

Footer snippet:

- © 2025 Sina Panahi. All rights reserved.


### B) Refund Policy (Digital Goods)

- Eligibility
    - Refunds are available within 14 days of purchase if the files are defective or inaccessible and the item has not been meaningfully consumed.
- Exclusions
    - Non-defective downloads, completed consumption beyond a reasonable trial, and buyer’s remorse are not eligible.
- Resolution
    - Zoroasterverse may offer a replacement file, alternate format, or refund at its discretion.
- Process
    - Email support@zoroasterverse.com with the order ID, a brief description of the issue, and any relevant screenshots.


### C) Reviews \& Community Guidelines

- Constructive first
    - Focus on pacing, character, worldbuilding, clarity, continuity, and emotional impact.
- Spoiler rules
    - Major plot points must be placed in the spoiler section; the system may auto-wrap detected spoilers.
    - Use the spoiler-free template when possible; use spoiler tags when discussing major moments or endings.
- Respect
    - No harassment, hate, personal attacks, or off-topic/promotional content.
- Moderation
    - Reviews may be moderated for spoilers, abuse, spam, or policy violations. Repeated violations can result in content removal and account action.


### D) Beta Reader Policy (Pre-NDA Summary)

- Selection
    - Applicants are scored on availability, analytical depth, communication tone, genre fit, and cohort balance (device/timezone/experience).
- Access
    - Hybrid reading: watermarked file downloads; portal-only chapters for sensitive drops.
- Obligations
    - Submit structured feedback by deadlines.
    - Convert the beta review into a public review on launch day to remain eligible for future cycles.
- Confidentiality
    - NDA required; content is confidential until public release. Leaks result in immediate revocation and may trigger legal action.
- Continuity
    - One strike (missed obligations) results in waitlist placement for the next cycle; reinstatement possible after compliance in a later round.


### E) Download Reset Policy

- If the 5-download limit is reached, email support@zoroasterverse.com with order ID to request a reset.
- Reasonable reset requests are processed within 2–3 business days.
- A self-serve reset request form may be added in the future.


### Age Guidance and Warnings

- Audience
    - Recommended for ages 13+ due to dark themes and narrative intensity.
- Content Warnings (may appear on product pages and relevant wiki entries)
    - May include: violence, war consequences, psychological manipulation, moral ambiguity.

Note: All texts are editable; language can be tightened or expanded before publishing.

***

## 2) Annotated Wireframes (structure and copy placement)

I will deliver annotated images/PDFs covering the following screens. Below is the structure outline and key microcopy so expectations are clear before the drawings are shared.

### Product Page

- Header: Title, Issue/Season, Preorder badge with month placeholder.
- “Beta Average Score” module:
    - Badge: “Beta Average Score”
    - Score display: 4.2/5 (example), “n=47 (Beta)”
    - Tooltip: “Based on early beta feedback; may differ from public reviews.”
- Editions and Formats:
    - Standard, Deluxe (with extras)
    - Formats: EPUB, PDF, MOBI
- Purchase CTA:
    - “Buy Issue” and “Add to Library” states, preorder countdown when applicable
- Content Warnings block:
    - “Recommended for ages 13+ for dark themes and narrative intensity.”
    - “May include: violence, war consequences, psychological manipulation, moral ambiguity.”
- License bullets (short version), download limit note.
- Reviews section (pre-release shows Beta reviews with a clear “Beta” label):
    - Filters and summary “Beta Snapshot” tab


### Library

- Owned items list with cover, edition, and formats.
- Download counters:
    - “EPUB Download (2/5 used)”
    - “Need a reset? Contact support@zoroasterverse.com”
- Watermark note: “Your files may include a purchaser-specific watermark.”
- “Mark as finished” toggle to unlock deeper spoilers across the site.
- Route suggestions panel based on owned/finished items.


### Character Page (Spoiler Capsules)

- Global spoiler toggle in header (Minimal/Standard/Full)
- Per-page override toggle
- Sections:
    - Overview (non-spoiler)
    - History with spoiler capsules:
        - Capsule label: “Reveals Branch: Silent Accord — tap to reveal”
    - Relations and timeline entries gated by ownership/progress
- Visual tags: Arc, Issue, POV, Branch, Ending-level, Severity (L/M/H)


### Event Page (Spoiler Capsules)

- Structure similar to Character page:
    - Date/Era
    - Participants (abstracted if hidden)
    - Outcome (in spoiler capsule), ownership/progress gating


### Beta Application → NDA Flow

- Application form sections:
    - Basics, Availability, Experience, Device/formats
    - Sample feedback task (short excerpt + 3 questions)
    - Consent to watermarking and NDA requirement
- Validation rules and progress bar
- Post-acceptance screen:
    - E-sign NDA checkpoint
    - Access granted confirmation + timeline (reading window and review deadline)


### Review Submission + Public Listing

- Submission:
    - Spoiler-free template fields
    - Spoiler-tagged additional fields (“Major Moments” capsule, route label)
    - Rating (1–5), helpful tags (pacing/character/worldbuilding/clarity/emotional impact)
- Public listing:
    - Filters: spoiler-free only, route label, POV focus, edition
    - Sort: Helpful, Newest, Highest, Lowest
    - Aggregates:
        - Pre-release: Beta Average Score (with n and “Beta” label)
        - Post-release: Public Average and Fresh ratio (≥4/5 counts as Fresh)

***

## 3) Beta Program Kit (specs and templates)

- Application form spec (fields, validations, required/optional)
- Scoring rubric:
    - Weights (example): Analytical Depth x1.5, Reliability x1.25, Genre Fit x1.25, Tone x1.0, Diversity Mix x1.0
    - Tie-breakers: Depth → Reliability → Diversity Mix
- Cohort balancing rules:
    - Device mix (EPUB/PDF), timezone spread, new vs experienced beta readers
- Email templates:
    - Acceptance (with cadence and deadlines)
    - Waitlist
    - Reading reminder (week 1)
    - Review reminder (review week)
    - Revocation (NDA/obligations breach)
    - Launch day: “Convert your beta review to public review”
- Public score wording:
    - “Beta Average Score reflects pre-release reader feedback and may evolve with public reviews.”

***

## 4) Content Inventory Templates (seeded)

- Works \& Editions
    - Fields: Season, Issue, Edition, Formats, Preorder/Release dates, Deluxe notes, Content warnings
- Characters
    - Fields: Arc, Issue of first appearance, POVs, spoiler severity, capsules (Minimal/Standard/Full), relations
- Events \& Timeline
    - Fields: Era, Date, Participants, Outcome, Ownership/progress locks, severity
- Route Nodes \& Endings
    - Fields: Abstract route label, Branch, Prerequisites, Ending category, severity
- Glossary
    - Fields: Term, Definition (minimal), Deeper content (gated), Arc/Issue tags
- Reviews (structure matching submission templates)
    - Fields: Headline, Quick take, Tags, Rating, Spoiler section, Route label, Edition, Verification flag

Seed rows will demonstrate correct tagging and spoiler gating.

***

## 5) Admin SOPs (checklists)

- New Issue Release
    - Create product → upload files (enable watermark) → set formats/regions/tax → set preorder/release dates → write product copy → content warnings → schedule announcement → configure Beta Snapshot visibility
- Beta Cycle
    - Open applications → score/rank → assign cohort → send acceptance/waitlist emails → NDA e-sign → publish beta drop (files/portal) → reminders → review collection → compile summary → enforce one-strike rule
- Spoiler QA
    - Preview Minimal/Standard/Full → resolve lint warnings → verify ownership/progress gates → publish
- Review Moderation
    - Auto-wrap spoilers → approve/deny queue → communicate with reviewers → uphold guidelines

***

## 6) Microcopy and Labels

- Spoiler modes:
    - Minimal: “High-level summaries only; major reveals hidden.”
    - Standard: “Reveals canon for content in your Library; abstracts unreached branches.”
    - Full: “Shows all canon, including branches and endings.”
- Beta Score tooltip: “Based on early beta feedback; may differ from public reviews.”
- Download counters: “2/5 downloads used — Need a reset? Email support@zoroasterverse.com.”
- Content warnings note: “These warnings may contain mild spoilers.”

***

## What I need (tiny confirmations)

- Support display name: use “Zoroasterverse Support” with support@zoroasterverse.com?
- For the preorder placeholder, is “[Month, Year]” okay until a date is chosen?

If that’s fine, I’ll send the policy pack and wireframes next, followed by the Beta Kit, inventory templates, SOPs, and microcopy bundle.

<div style="text-align: center">⁂</div>

[^9_1]: 4.-Locked-Decisions-What-Happens-Next2.md

[^9_2]: 1.-Website-Blueprint-for-the-Novel-Series.md

[^9_3]: 2.-Where-We-Begin.md

[^9_4]: 3.-locking-initial-decisions-and-moving-forward.md


---

# Excellent — moving into deliverables production

All approvals and preferences are locked. Proceeding with the final documents and artifacts (no code). Below is exactly what will be produced and in what order, plus how each item will be tailored to zoroasterverse.com.

## Delivery Order

1) Policy pack (paste‑ready text)

- Copyright \& Licensing
- Refunds (digital goods)
- Reviews \& Community Guidelines
- Beta Reader Policy (pre‑NDA summary)
- Download Reset Policy
- Footer and product‑page bullet snippets
- Contacts: support@zoroasterverse.com (primary), legal@, press@, beta@

2) Annotated wireframes (PDF/images)

- Product Page (with “Beta Average Score,” preorder state, formats, license bullets, 13+ guidance, content warnings)
- Library (download counters 0/5, watermark note, “Mark as finished” to unlock spoilers, route suggestions)
- Character and Event pages (spoiler capsules, global/per‑page toggle, ownership/progress gating)
- Beta Application → NDA flow (scored fields, validation, e‑sign checkpoint)
- Review submission and public listing (spoiler‑free/tagged templates, filters, aggregates, helpfulness)

3) Beta Program Kit

- Application form spec, validation rules, scoring weights, tie‑breakers
- Cohort balancing rules (device, timezone, experience)
- Email templates: acceptance, waitlist, reading reminder, review reminder, revocation, launch‑day conversion to public review
- Public “Beta Average Score” copy and tooltip

4) Content inventory spreadsheets (seeded)

- Works \& Editions, Characters, Events/Timeline, Route Nodes/Endings, Glossary, Reviews
- Preconfigured columns for spoiler level, ownership locks, arc/issue/branch/POV tags, capsule text
- Placeholder preorder month; placeholder abstract route labels

5) Admin SOP checklists

- New Issue Release
- Beta Cycle
- Spoiler QA
- Review Moderation

6) Microcopy bundle

- Age guidance: “Recommended for ages 13+ for dark themes and narrative intensity.”
- Content warnings (editable set)
- Beta Score tooltip
- Download/reset prompts
- Spoiler mode labels and 1‑line descriptions


## Small defaults confirmed for zoroasterverse.com

- Support display name: “Zoroasterverse Support”
- Age guidance: 13+ recommended (no age gate)
- Route labels: placeholder neutral set (replaceable)
- Preorder timeline: “[Month, Year]” placeholder until finalized
- Regions: none excluded at launch
- Beta cadence: 2 weeks reading + 1 week reviews per issue
- Enforcement: one strike → waitlist next cycle
- Download limit: 5 per format, resets via support email


## What happens after you receive the deliverables

- Review and mark any edits directly in the policy texts and wireframe annotations.
- Approve the spreadsheet column schema so content entry can begin immediately.
- We’ll run a dry‑run of the beta scoring rubric on 3–5 mock applications to validate weights and tie‑breakers.
- Once the above are signed off, we’ll lock the MVP IA and produce the implementation plan (still no code), including:
    - CMS structure and roles
    - Product page and Library data bindings
    - Spoiler tagging workflow and QA steps
    - Review moderation workflow and thresholds
    - Beta program operation timeline and comms triggers

I’ll start sending the Policy Pack and Wireframes first.

<div style="text-align: center">⁂</div>

[^10_1]: 4.-Locked-Decisions-What-Happens-Next2.md

[^10_2]: 1.-Website-Blueprint-for-the-Novel-Series.md

[^10_3]: 2.-Where-We-Begin.md

[^10_4]: 3.-locking-initial-decisions-and-moving-forward.md


---

# Project Status Review: What’s Finalized vs. What’s Next

This is a clean snapshot of decisions made, deliverables in progress, and remaining work—so planning stays clear and momentum stays high.

## Finalized Decisions

- Brand and contact
    - Site: zoroasterverse.com
    - Emails: support@zoroasterverse.com (primary), legal@, press@, beta@
    - Support display name: Zoroasterverse Support
- Audience and content guidance
    - Age guidance: 13+ recommended
    - Content warnings will be shown on product pages and relevant wiki entries
- Commerce and files
    - Download limit: 5 per format (resets via support)
    - Watermarking: enabled for beta; optionally used for customers later as needed
    - Refund policy stance: digital-goods specific, limited to defects/inaccessibility
- Reviews and community
    - Structured review templates: spoiler-free and spoiler-tagged, with moderation and spoiler auto-wrap
    - “Beta Average Score”: displayed on product page pre-release with a clear “Beta” label and sample size
- Spoiler system
    - Modes: Minimal (guest and logged-in non-owners), Standard (owners), Full (opt-in)
    - Ownership/progress gating and spoiler capsules
    - Admin “spoiler lint” preview workflow
- Beta program
    - Cohort size: 40–60 (cycle 1)
    - Cadence: 2 weeks of reading + 1 week for reviews per issue
    - Reading mode: hybrid (watermarked files + portal-only for sensitive drops)
    - Enforcement: one strike → waitlist next cycle
    - Obligation: convert beta review to public review at launch
- Roadmap approach
    - No code yet; design-first with policies, wireframes, data schemas, SOPs, and templates
    - Subscriptions: deferred; architecture kept future-ready


## Deliverables In Progress (next to share)

- Policy pack (paste-ready)
    - Copyright \& Licensing
    - Refund Policy (digital)
    - Reviews \& Community Guidelines
    - Beta Reader Policy (pre-NDA summary)
    - Download Reset Policy
    - Footer snippet and product-page bullets
- Annotated wireframes (low-fidelity)
    - Product Page (with Beta Average Score, preorder state, editions/formats, warnings, license bullets)
    - Library (download counters, watermark note, “Mark as finished,” route suggestions)
    - Character/Event pages (spoiler capsules, global/per-page toggles)
    - Beta Application → NDA flow (scored form, validation, e-sign checkpoint)
    - Review submission + public listing (filters, aggregates, helpfulness)
- Beta Program Kit
    - Application spec, scoring rubric/weights, cohort balancing rules
    - Email templates (acceptance, waitlist, reminders, revocation, launch-day conversion)
- Content inventory spreadsheets (seeded examples)
    - Works \& Editions, Characters, Events/Timeline, Route Nodes/Endings, Glossary, Reviews
    - Columns for spoiler severity, ownership locks, arc/issue/branch/POV tags, capsule text
    - Placeholder preorder month; placeholder abstract route labels
- Admin SOP checklists
    - New Issue Release, Beta Cycle, Spoiler QA, Review Moderation
- Microcopy bundle
    - Age guidance, content warnings, Beta Score tooltip, spoiler mode labels, download/reset prompts


## What Still Needs Decisions (minor items)

- Preorder month for first issue (placeholder is fine for now)
- Final abstract route label set (using placeholders; can rename later)
- Optional: whether to show a “Fresh ratio” badge (≥4/5) alongside averages post-release


## Work To Do After Current Deliverables

- Review and mark edits on:
    - Policy pack (tighten language if desired)
    - Wireframe annotations (layout, copy placement, interactions)
    - Spreadsheet schemas (ensure tags/spoiler levels fit the worldbuilding model)
    - Beta rubric weights (quick dry-run on 3–5 mock applications)
- Prepare initial content entries (small sample to validate spoiler gating)
    - 1 season, 2 issues (standard/deluxe)
    - 6 characters (2 POVs)
    - 10 events (2 eras)
    - 4 route nodes, 2 endings (with abstract labels)
    - 15 glossary terms
    - 3 seed beta reviews for layout testing


## Risks and How We’re Handling Them

- Spoiler leakage
    - Mitigation: mode previews, spoiler lint, explicit capsule gating, ownership/progress toggles
- Beta overhead
    - Mitigation: medium cohort (40–60), strong rubric, one-strike rule, templated comms
- Policy ambiguity
    - Mitigation: paste-ready texts, clear bullets on product pages, consistent footer/legal
- Future subscription complexity
    - Mitigation: content/data model designed to accept passes/memberships later with minimal rework


## Immediate Next Step

- I will deliver the Policy Pack first, followed by the annotated wireframes. After review, we’ll finalize the spreadsheet templates, Beta Kit, SOPs, and microcopy. Then we’ll lock the MVP IA and draft the implementation plan—still without writing code.

If any priorities should shift (e.g., wireframes before policies), say the word and the order will be adjusted.

<div style="text-align: center">⁂</div>

[^11_1]: 8.-Excellent-moving-into-deliverables-production.md

[^11_2]: 1.-Website-Blueprint-for-the-Novel-Series.md

[^11_3]: 2.-Where-We-Begin.md

[^11_4]: 3.-locking-initial-decisions-and-moving-forward.md

[^11_5]: 4.-Locked-Decisions-What-Happens-Next2.md

[^11_6]: 5.-setting-up-contact-age-guidance-and-next-deliverables.md

[^11_7]: 6.-proceeding-with-deliverables.md

[^11_8]: 7.-Acknowledged-proceeding-with-deliverables.md


---

# Policy Pack (Paste-Ready Text)

All texts below are ready to paste into a CMS. They use “Sina Panahi” and zoroasterverse.com domain emails, reflect the approved decisions, and include short product-page bullets and a footer snippet.

## Copyright \& Licensing

Title: Copyright \& Licensing

© 2025 Sina Panahi. All rights reserved.

License

- By purchasing an ebook from Zoroasterverse, the customer receives a non-transferable, non-exclusive license to download and read for personal, non-commercial use only.
- Prohibited without prior written permission from the author: sharing, reselling, uploading to public repositories, or distributing the ebook in any format.
- Access may be suspended or revoked for policy violations or fraudulent activity.

Anti-Piracy and Watermarking

- Downloaded files may include a purchaser-specific watermark for security and anti-piracy purposes.
- We may log access activity to investigate fraud and abuse.

Download Limits

- Each purchase includes up to 5 downloads per format (e.g., EPUB, PDF, MOBI).
- If the limit is reached due to device changes or technical issues, email support@zoroasterverse.com with the order ID to request a reset. Reasonable requests are processed within 2–3 business days.

Contact

- Support: support@zoroasterverse.com
- Legal/NDA \& DMCA: legal@zoroasterverse.com
- Press/partnerships: press@zoroasterverse.com

Last updated: [Month, Year]

Product-page short bullets (for use on product pages)

- Personal-use license
- 5 downloads per format
- Watermarking for security
- Digital-only refund policy applies

—

## Refund Policy (Digital Goods)

Title: Refund Policy (Digital Goods)

Eligibility

- Refunds are available within 14 days of purchase if:
    - Files are defective or inaccessible; and
    - The item has not been meaningfully consumed (e.g., not fully downloaded/used beyond a reasonable trial).
- We may provide a replacement file or alternate format before issuing a refund.

Exclusions

- Completed downloads beyond a reasonable trial period.
- Non-defective files or buyer’s remorse.
- Issues caused by unsupported devices/apps (we will still try to help you troubleshoot).

How to Request

- Email support@zoroasterverse.com with:
    - Order ID
    - A brief description of the issue
    - Relevant screenshots or error messages (if any)
- Requests are reviewed within 2–3 business days.

Notes

- If a refund is granted, access to the refunded digital products may be revoked.
- This policy applies to digital ebooks only and does not cover future physical merchandise or print editions.

Last updated: [Month, Year]

—

## Reviews \& Community Guidelines

Title: Reviews \& Community Guidelines

Purpose

- Reviews help readers decide what to read and help the author improve. Keep feedback honest, respectful, and useful.

Be Constructive

- Focus on pacing, character, worldbuilding, clarity, continuity, and emotional impact.
- Explain what worked or didn’t, and why.

Spoiler Rules

- Major plot points, route outcomes, and endings must be placed inside the spoiler section.
- The system may auto-detect and auto-wrap spoilers if tags are missing.
- Use the spoiler-free template when possible; use spoiler tags when discussing major moments.

Respect and Relevance

- No harassment, hate speech, personal attacks, or doxxing.
- No spam, unrelated links, or self-promotion.
- Keep reviews relevant to the work and edition reviewed.

Moderation

- Reviews may be moderated for spoilers, abuse, spam, or policy violations.
- Repeat violations may result in removal of content and/or account restrictions.

Badges and Verification

- “Verified Purchase” badges appear when reviews are posted from accounts that own the product.
- Beta readers must convert their beta review into a public review on launch day to remain eligible for future cycles.

Reporting

- To report a review, use the in-page report function or email support@zoroasterverse.com with a link and reason.

Last updated: [Month, Year]

—

## Beta Reader Policy (Pre‑NDA Summary)

Title: Beta Reader Policy (Pre‑NDA Summary)

Overview

- The beta program provides early access to draft content in exchange for structured, timely feedback. Participation is limited and selection is merit-based.

Selection

- Applicants are scored on:
    - Availability \& reliability
    - Analytical depth (sample feedback)
    - Communication tone
    - Genre fit (branching narratives, multi-POV)
    - Cohort balance (device/timezone/experience)
- Cohorts typically include 40–60 readers per issue.

Access \& Reading Mode

- Hybrid access:
    - Watermarked file downloads for general beta drops.
    - Portal-only chapters for sensitive content.

Obligations

- Submit structured feedback by deadlines.
- Convert beta review to a public review on launch day (spoiler-free or spoiler-tagged template).
- Participate respectfully in any follow-up clarifications.

Confidentiality \& NDA

- NDA is required prior to access.
- Content is confidential until public release.
- Leaks or sharing files externally result in immediate revocation and may trigger legal action.

Enforcement

- One strike (missed deadlines or failure to convert review at launch) → waitlist for the next cycle; reinstatement possible after demonstrated compliance later.
- Access may be revoked for policy or NDA violations.

Support

- Beta operations: beta@zoroasterverse.com (or support@zoroasterverse.com if consolidated)
- Legal inquiries: legal@zoroasterverse.com

Last updated: [Month, Year]

—

## Download Reset Policy

Title: Download Reset Policy

Standard Limits

- Each purchase includes up to 5 downloads per format (e.g., EPUB, PDF, MOBI).

When to Request a Reset

- You changed devices or reading apps multiple times.
- A download was interrupted or corrupted.
- You legitimately need additional downloads for personal use.

How to Request

- Email support@zoroasterverse.com with:
    - Order ID
    - The format(s) you need reset
    - A short note on why you need the reset
- We process reasonable requests within 2–3 business days.

Notes

- Excessive reset requests may be declined or investigated for abuse.
- Watermarking may be applied to downloaded files.

Last updated: [Month, Year]

—

## Footer Snippet and Product-Page Bullets

Footer legal snippet

- © 2025 Sina Panahi. All rights reserved.

Product-page bullets (place under purchase section)

- Personal-use license
- 5 downloads per format
- Watermarking for security
- Digital-only refund policy applies
- Recommended for ages 13+ for dark themes and narrative intensity

—

If any tone, phrasing, or sections should be adjusted (e.g., stronger anti-piracy language or a different reset turnaround time), specify the changes and a revised version will be provided immediately.

<div style="text-align: center">⁂</div>

[^12_1]: 8.-Excellent-moving-into-deliverables-production.md

[^12_2]: 1.-Website-Blueprint-for-the-Novel-Series.md

[^12_3]: 2.-Where-We-Begin.md

[^12_4]: 3.-locking-initial-decisions-and-moving-forward.md

[^12_5]: 4.-Locked-Decisions-What-Happens-Next2.md

[^12_6]: 5.-setting-up-contact-age-guidance-and-next-deliverables.md

[^12_7]: 6.-proceeding-with-deliverables.md

[^12_8]: 7.-Acknowledged-proceeding-with-deliverables.md


---

# Next Steps

Here’s the precise, no-code sequence to keep momentum and get to an implementation-ready package.

## 1) Ship the remaining deliverables (in this order)

- Annotated wireframes (PDF/images):
    - Product Page (with Beta Average Score, preorder state, formats, license bullets, 13+ warnings)
    - Library (download counters 0/5, watermark note, “Mark as finished,” route suggestions)
    - Character/Event pages (spoiler capsules, global/per-page toggles, ownership/progress gating)
    - Beta Application → NDA flow (scored form, validation, e-sign checkpoint)
    - Review submission + public listing (spoiler-free/tagged, filters, aggregates, helpfulness)
- Beta Program Kit:
    - Application spec, scoring weights, tie-breakers, cohort-balancing rules
    - Email templates (acceptance, waitlist, reminders, revocation, launch-day conversion)
- Content inventory templates (seeded):
    - Works \& Editions, Characters, Events/Timeline, Route Nodes/Endings, Glossary, Reviews
    - With spoiler severity, ownership locks, arc/issue/branch/POV tags, capsule text
- Admin SOP checklists:
    - New Issue Release, Beta Cycle, Spoiler QA, Review Moderation
- Microcopy bundle:
    - Age guidance, content warnings, Beta Score tooltip, download/reset prompts, spoiler mode labels


## 2) Quick inputs needed to finalize copy and screens

- Preorder placeholder text: keep “[Month, Year]” for Product Page?
- Any changes to the default content warnings (currently: violence, war consequences, psychological manipulation, moral ambiguity)?
- Confirm support display name “Zoroasterverse Support” is good for footer and emails.

If these are fine as-is, production continues without delay.

## 3) Review cycle (fast feedback loop)

- Review the policy pack you just received and comment inline on any wording to tighten.
- Review wireframe annotations:
    - Confirm module placement, copy tone, and interactions.
    - Flag any sections that need different emphasis (e.g., moving Beta Snapshot higher/lower).
- Validate spreadsheet columns with 2–3 sample rows per sheet to confirm spoiler gating works as intended.


## 4) Dry-run critical workflows (paper tests)

- Beta rubric test: score 3–5 mock applications to validate weights/tie-breakers and balance rules.
- Spoiler QA pass: take one Character and one Event entry, tag them fully, and preview through Minimal/Standard/Full to ensure no leakage.
- Review pipeline: submit one spoiler-free and one spoiler-tagged test review and verify moderation cues and display variants.


## 5) Lock MVP scope and produce the implementation plan

- Freeze the IA and components for MVP:
    - Home, Store, Checkout, Accounts, Library, Reviews, Blog/News
    - Worldbuilding wiki (read-only), Timelines (static), Series Guide
- Implementation plan (still no code):
    - CMS data models and roles
    - Product Page and Library bindings (downloads, counters, watermark note)
    - Spoiler tagging workflow + QA steps
    - Review moderation thresholds and queue handling
    - Beta program operational timeline and comms triggers


## 6) Content entry kickoff (small, testable slice)

- Enter the seed set:
    - 1 season, 2 issues (standard/deluxe)
    - 6 characters (2 POVs)
    - 10 events (2 eras)
    - 4 route nodes, 2 endings (abstract labels)
    - 15 glossary terms
    - 3 seed beta reviews


## 7) Go/No-Go checklist before build

- Policies approved
- Wireframes approved
- Spreadsheet schemas approved (with sample data)
- Beta kit approved (rubric, emails, cadence)
- SOPs approved (release/beta/spoiler QA/reviews)
- Microcopy approved

If desired, the order can be adjusted to prioritize wireframes first. Otherwise, I’ll proceed by sending the annotated wireframes next for review.

<div style="text-align: center">⁂</div>

[^13_1]: 8.-Excellent-moving-into-deliverables-production.md

[^13_2]: 1.-Website-Blueprint-for-the-Novel-Series.md

[^13_3]: 2.-Where-We-Begin.md

[^13_4]: 3.-locking-initial-decisions-and-moving-forward.md

[^13_5]: 4.-Locked-Decisions-What-Happens-Next2.md

[^13_6]: 5.-setting-up-contact-age-guidance-and-next-deliverables.md

[^13_7]: 6.-proceeding-with-deliverables.md

[^13_8]: 7.-Acknowledged-proceeding-with-deliverables.md


---

# Annotated Wireframes — Structure, Key Components, and Copy

Below are detailed, no-code wireframe specifications for each screen: layout structure, component behavior, data bindings, and paste-ready microcopy. These are ready for drawing into PDF/images or direct translation into a design tool.

## 1) Product Page

### A. Hero Section

- Elements:
    - Cover image (left on desktop; top on mobile)
    - Title, Issue/Season label
    - Edition selector (Standard/Deluxe)
    - Preorder badge (if applicable): “Preorder: [Month, Year]”
- Notes:
    - On release, Preorder badge auto-switches to “Available Now.”
    - Deluxe shows extras list (annotations, concept art, soundtrack links) under selector.


### B. Purchase Module

- Price display per edition
- CTA:
    - If preorder: “Preorder Now”
    - If released: “Buy Issue”
    - If owned: “Add to Library” switches to “In Library”
- Formats checklist:
    - EPUB, PDF, MOBI
    - License bullet reminder under formats
- Content warnings summary:
    - “Recommended for ages 13+ for dark themes and narrative intensity.”
    - “May include: violence, war consequences, psychological manipulation, moral ambiguity.”

Microcopy:

- License bullets:
    - “Personal-use license”
    - “5 downloads per format”
    - “Watermarking for security”
    - “Digital-only refund policy applies”
- Tooltip on downloads:
    - “Each purchase includes up to 5 downloads per format; resets via support.”


### C. Beta Average Score Module (Pre-Release)

- Badge: “Beta Average Score”
- Score display: “4.2/5” + “n=47 (Beta)”
- Tooltip: “Based on early beta feedback; may differ from public reviews.”
- Note:
    - Place near purchase module for visibility.
    - Collapsible details: “What counts as ‘Fresh’?” → “Ratings ≥4/5 count as ‘Fresh’.”


### D. Details Section

- Tabs: Overview | Editions | Extras (Deluxe only) | Tech Specs (formats, file sizes)
- Overview:
    - Short synopsis (non-spoiler)
    - Reading order link to Series Guide
- Tech Specs:
    - Formats, file size per format, download note, recommended readers/apps


### E. Reviews Section

- Pre-release:
    - “Beta Snapshot” tab first
    - Individual beta reviews labeled “Beta”
    - Filters: spoiler-free only; route label; POV focus; edition
- Post-release:
    - “Public Reviews” tab first
    - Aggregates: Public Average; Fresh ratio badge (optional toggle later)
- Sort: Helpful, Newest, Highest, Lowest
- Card content:
    - Headline, quick take, tags, rating, spoiler capsule (if present), route label (abstracted), edition, Verified Purchase badge (post-release)


### F. Footer Banner (contextual)

- “Have questions? Email support@zoroasterverse.com”

Behavior notes:

- If user is logged in and owns the issue, elevate more detailed non-spoiler copy; do not reveal spoilers.
- Maintain canonical non-spoiler text at Minimal level; deeper details appear only within spoiler capsules across the site.

***

## 2) Library

### A. Library Header

- Title: “Your Library”
- Subnav chips: All | Issues | Bundles | Deluxe | Downloads
- Info banner (dismissible):
    - “Files may include a purchaser-specific watermark. Download limits: 5 per format.”


### B. Item Cards (per owned product)

- Left: cover thumbnail
- Center:
    - Title + Edition tag
    - Formats with counters:
        - EPUB: “Download (2/5 used)”
        - PDF: “Download (0/5 used)”
        - MOBI: “Download (5/5 used)”
- Right:
    - “Mark as finished” toggle
    - “Need a reset? Email support@zoroasterverse.com”

Microcopy:

- Under counters: “Problems downloading? Check your reader app supports EPUB/PDF/MOBI.”
- Reset request hint: “Include your Order ID.”

Behavior notes:

- “Mark as finished” updates site-wide spoiler unlocks (ownership/progress gating).
- Counters decrement on successful download events; show spinner and success/failure states.

***

## 3) Character Page (Spoiler-Aware)

### A. Header + Controls

- Character name (non-spoiler-safe)
- Global spoiler toggle (header-level): Minimal | Standard | Full
- Per-page override toggle: “Adjust for this page only”

Tooltips:

- Minimal: “High-level summaries only; major reveals hidden.”
- Standard: “Reveals canon for content in your Library; abstracts unreached branches.”
- Full: “Shows all canon, including branches and endings.”


### B. Non-Spoiler Overview

- Short bio that avoids late-appearance details and route outcomes
- Tags row (non-spoiler): Arc, Issue of first appearance (abstracted if needed), POV status (Y/N)


### C. Spoiler Capsules

- Sections: History, Relationships, Key Moments, Appearances Timeline
- Capsule design:
    - Label example: “Reveals Branch: Silent Accord — tap to reveal”
    - Severity badge: L/M/H
    - Ownership/progress lock indicator if user hasn’t finished related content
- Inside capsule:
    - Rich text explaining the event/relationship/change
    - Cross-links to related Events and Factions (respecting current spoiler mode)

Behavior notes:

- If user toggles Full mode, display route labels (abstracted) and ending tags where applicable.
- Capsule warns on reveal: “Contains spoilers tied to Issue X.”

***

## 4) Event Page (Spoiler-Aware)

### A. Header + Metadata

- Event title (non-spoiler naming)
- Era/Date, Participants (abstracted if hidden), Location


### B. Summary (Minimal-safe)

- One-paragraph non-spoiler summary


### C. Spoiler Capsules

- Outcome capsule:
    - Label: “Reveals outcome for Branch: Iron Vow — tap to reveal”
    - Severity badge
- Timeline placement snippet (with gate as needed)

Behavior notes:

- If user owns and marked-finished related Issue/Season, elevate to Standard details.
- Cross-links to Character and Route Nodes gated by current mode.

***

## 5) Beta Application → NDA Flow

### A. Application Form (Stepper UI)

- Step 1: Basics
    - Name, Email, Country/Timezone, Reading speed estimate
- Step 2: Experience
    - Past beta reading (titles/links), Genres, Strengths (plot, pacing, character, continuity)
- Step 3: Availability \& Devices
    - Weekly hours during window, Device formats (EPUB/PDF)
- Step 4: Sample Feedback Task
    - Short excerpt + 3 guided questions (free-text)
- Step 5: Consents
    - Consent to watermarking
    - Agreement to sign NDA if selected

Validation:

- Required fields for each step; disabled “Next” until complete
- Auto-save on step change

Microcopy:

- “Strong applications are specific and cite examples.”
- “Watermarked files are for your eyes only; leaks result in immediate revocation.”


### B. Post-Application States

- Confirmation screen: “Thanks! We’ll notify you by email.”
- Acceptance email (template-ready): includes cohort window, deadlines, link to NDA
- Waitlist email
- Reminder emails: Week 1 reading; Review week


### C. NDA E‑Sign Checkpoint

- Inline summary:
    - Confidentiality scope, no sharing, watermarking, revocation policy
- Actions:
    - “View Full NDA” (modal)
    - “Sign \& Continue”
- Success:
    - “Access granted” screen with “Start Reading” and “Feedback Due” dates

***

## 6) Review Submission + Public Listing

### A. Submission Form (owned users and beta readers)

- Template selector:
    - Spoiler-free
    - Spoiler-tagged
- Common fields:
    - Headline (max 80)
    - Quick take (1–2 sentences)
    - Tags (choose 2–3): pacing, character, worldbuilding, clarity, emotional impact
    - Rating (1–5)
- Spoiler-tagged extras:
    - “Major Moments” inside spoiler capsule
    - Route label (abstracted picker)
    - Ending type (hidden unless Full mode or owner)

Auto-wrap:

- If system detects spoilers in spoiler-free fields, show non-blocking warning: “We found potential spoilers. Move them into the spoiler section?”


### B. Public Listing

- Filters:
    - Spoiler-free only
    - Route label
    - POV focus
    - Edition (standard/deluxe)
- Sort:
    - Helpful, Newest, Highest, Lowest
- Aggregates:
    - Pre-release: “Beta Average Score (n=XX, Beta)”
    - Post-release: “Public Average” + optional “Fresh ratio”

Card layout:

- Headline, quick take, tags, rating stars
- If spoiler content: collapsed capsule with “Tap to reveal”
- Metadata: route label (abstracted), edition, Verified Purchase flag (post-release)

Moderation cues:

- Queue flags: spoilers, abuse, off-topic
- Inline status for reviewer: “Awaiting moderation,” “Published,” or “Updated after moderation”

***

# Cross-Screen Components and Behaviors

- Global spoiler toggle persists in header with last-used mode per session.
- Ownership/progress gating:
    - “Mark as finished” in Library triggers wider unlocks.
    - Capsules respect both ownership and finished state.
- Watermark note:
    - Displayed in Library and on download confirmation/receipt UX.


# Copy Snippets (Ready to Paste)

- Beta Score tooltip: “Based on early beta feedback; may differ from public reviews.”
- Download counter note: “Each purchase includes up to 5 downloads per format.”
- Reset prompt: “Need a reset? Email support@zoroasterverse.com (include your Order ID).”
- Spoiler mode labels:
    - Minimal: “High-level summaries only; major reveals hidden.”
    - Standard: “Reveals canon for content in your Library; abstracts unreached branches.”
    - Full: “Shows all canon, including branches and endings.”


# Handoff Checklist for Design

- Use these sections as artboards: Product, Library, Character, Event, Beta Application, NDA checkpoint, Review Submission, Review Listing.
- Annotate each component with:
    - State variants (preorder vs release; owned vs not; Minimal/Standard/Full)
    - Error/empty/loading states (e.g., downloads exhausted; no reviews)
    - Tooltip/capsule texts from above
- Export as PDF/images for review; keep copy layers editable.

If preferred, I can convert these into a Figma-ready structure outline next or provide low‑fidelity sketches with numbered annotations.

<div style="text-align: center">⁂</div>

[^14_1]: 8.-Excellent-moving-into-deliverables-production.md

[^14_2]: 1.-Website-Blueprint-for-the-Novel-Series.md

[^14_3]: 2.-Where-We-Begin.md

[^14_4]: 3.-locking-initial-decisions-and-moving-forward.md

[^14_5]: 4.-Locked-Decisions-What-Happens-Next2.md

[^14_6]: 5.-setting-up-contact-age-guidance-and-next-deliverables.md

[^14_7]: 6.-proceeding-with-deliverables.md

[^14_8]: 7.-Acknowledged-proceeding-with-deliverables.md

[^14_9]: 10.-Next-Steps.md

[^14_10]: 9.-Project-Status-Review.md


---

# Next: Beta Program Kit

Confirmed. The next deliverable is the full Beta Program Kit. Below is the complete, paste‑ready spec you can review and edit. Once approved, I’ll package the email templates and scoring sheets as files.

## 1) Application Spec (fields, validation, storage)

Sections and fields

- Basics
    - Full name (required, text)
    - Email (required, email format, unique)
    - Country/Timezone (required, select)
    - Reading speed (required, select: <2h/wk, 2–4h/wk, 5–7h/wk, 8h+)
- Experience
    - Prior beta experience (optional, multi-line text; encourage links/titles)
    - Favorite genres (required, multi-select)
    - Strengths (required, multi-select: plot, pacing, character, continuity, clarity, worldbuilding)
- Availability \& Devices
    - Weekly availability during window (required, select: 2–3h, 4–6h, 7–10h, 10h+)
    - Preferred formats (required, multi-select: EPUB, PDF)
    - Primary device (optional, select: eReader, tablet, phone, desktop)
- Sample Feedback Task
    - Prompt: “Read this short excerpt (≈700–900 words). Answer 3 questions.”
    - Q1: What worked best and why? (required, 100–300 words)
    - Q2: What confused you and how would you clarify it? (required, 100–300 words)
    - Q3: One actionable suggestion (required, 60–200 words)
- Consents
    - I consent to watermarked files (required, checkbox)
    - I agree to sign the NDA if selected (required, checkbox)
    - Optional: share device logs for QA (optional, checkbox)

Validation

- Required fields enforced per section before continuing.
- Word-count hints/warnings for sample answers.
- Email uniqueness check; rate limit submissions.

Storage

- Persist as Application entity with fields:
    - basics, experience, availability, devices, sample_feedback, consents, timestamps, status (submitted/shortlisted/accepted/waitlist/rejected).


## 2) Scoring Rubric and Weights

Criteria (0–5 each, before weights)

- Analytical Depth: specificity, evidence, and clarity of reasoning in sample feedback.
- Reliability \& Availability: stated availability fit for the window; prior track record if provided.
- Communication Tone: respectful, constructive, actionable phrasing.
- Genre Fit: familiarity with branching narratives, multi‑POV tolerance.
- Diversity Mix: contributes to cohort diversity (device types, timezone spread, experience levels).

Weights

- Analytical Depth ×1.5
- Reliability \& Availability ×1.25
- Genre Fit ×1.25
- Tone ×1.0
- Diversity Mix ×1.0

Computation

- Normalize raw 0–5 to weighted score; total score = sum(weighted).
- Auto-rank descending.

Review aids

- Depth quick rubric:
    - 5: Specific examples + explains why + actionable fix
    - 3: General points + some reasons
    - 1: Vague sentiment, no evidence
- Tone quick rubric:
    - 5: Respectful, objective, actionable
    - 3: Neutral but light on solutions
    - 1: Dismissive or harsh


## 3) Cohort-Balancing Rules and Tie‑Breakers

Cohort target

- Size: 40–60.
- Device mix: aim ≥25% each for EPUB‑on‑eReader and PDF‑on‑tablet/desktop; allow flexible ranges.
- Timezones: cover Americas, Europe/Africa, Asia/Oceania; aim for at least 25% each where possible.
- Experience: ≥30% first‑time beta readers; ≥30% experienced.
- Formats: ensure both EPUB and PDF are represented.

Selection flow

- Step 1: Filter incomplete/non-consent applications.
- Step 2: Compute weighted total score; create ranked list.
- Step 3: Iteratively fill cohort while enforcing device/timezone/experience quotas.
- Step 4: Tie‑breakers in order:
    - Higher Analytical Depth
    - Higher Reliability \& Availability
    - Improves timezone/device diversity
    - Earlier submission time (as last resort)
- Step 5: Build waitlist (top 20–30% after cutoff) preserving diversity.

Backfill

- If a selected reader drops or misses NDA deadline, invite next on waitlist matching the quota deficit (e.g., fill EPUB/eReader gap).


## 4) Participation Rules (concise, enforceable)

- Deliverables
    - Submit structured feedback by the stated deadline via the portal form.
    - On launch day, convert beta review to a public review (spoiler‑free or spoiler‑tagged).
- Conduct
    - Respectful communication; follow spoiler rules; no leaks or sharing.
    - Use assigned channels for feedback and issue reporting.
- Enforcement
    - One strike (missed deadline or no review conversion) → waitlist for next cycle.
    - NDA or policy breach → immediate revocation; possible permanent removal.


## 5) Operational Timeline (per issue)

- Day 0: Applications close → scoring and shortlist (48–72h).
- Day 2–3: Send acceptance/waitlist emails → NDA e‑sign.
- Day 5: Beta drop opens (watermarked files + portal-only for sensitive content).
- Day 5–19: Reading window (2 weeks) → mid‑window reminder.
- Day 19–26: Review window (1 week) → 2 reminders (opening + 48h before close).
- Launch Day: Trigger “convert to public review” email; verify conversions in 24–48h.


## 6) Email Templates (paste‑ready)

Acceptance (Subject: Welcome to the Zoroasterverse Beta — You’re In)

- Hi [First Name],
    - You’ve been selected for the upcoming beta cohort (Window: [Dates], Timezone: [TZ]).
    - What’s next:
        - Sign the NDA here: [link]
        - Access opens: [date/time]
        - Reading window: [date]–[date]
        - Feedback due: [deadline date/time]
    - Format access: EPUB/PDF (watermarked), portal‑only for sensitive drops.
    - Reminders will be sent mid‑window and 48h before deadline.
    - Questions? beta@zoroasterverse.com or support@zoroasterverse.com
    - Thank you, and welcome aboard.
- Zoroasterverse Beta Team

Waitlist (Subject: Zoroasterverse Beta — Waitlist Status)

- Hi [First Name],
    - Thank you for applying. The current cohort is full; you’ve been placed on the waitlist.
    - We’ll reach out if a spot opens or in future cycles.
    - We appreciate your interest and hope to read with you soon.
- Zoroasterverse Beta Team

Reminder — Mid‑Window Reading (Subject: Beta Check‑In — How’s the Read Going?)

- Hi [First Name],
    - Quick check‑in. Reading continues through [date]. Feedback is due by [deadline].
    - If anything blocks progress (format/device issues), reply to this email.
- Beta Team

Reminder — 48h Before Feedback Due (Subject: 48 Hours Left — Feedback Due [deadline])

- Hi [First Name],
    - A quick reminder that feedback is due in 48 hours: [deadline date/time, TZ].
    - Submit here: [portal link]
    - Thanks for keeping us on schedule!
- Beta Team

Revocation (Subject: Beta Access Revoked — Policy/NDA Breach)

- Hi [First Name],
    - Your beta access has been revoked due to a policy/NDA violation: [brief reason].
    - This decision may affect eligibility for future cycles.
    - If you believe this is an error, reply within 7 days.
- Beta Team

Launch‑Day Conversion (Subject: It’s Live — Convert Your Beta Review Today)

- Hi [First Name],
    - The issue has launched! Please convert your beta review to a public review today to remain eligible for future betas.
    - Convert here: [review conversion link]
    - Thank you for helping other readers discover the story.
- Beta Team


## 7) Portal Forms and QA

Feedback form (beta)

- Fields:
    - Overall rating (1–5)
    - Quick take (1–2 sentences)
    - Highlights tags (choose 2–3): pacing, character, worldbuilding, clarity, emotional impact
    - Major moments (spoiler capsule)
    - Confusion points (text)
    - Suggestions (text)
    - Device/format used (select)
- Validation:
    - Required rating, quick take, tags, and at least one of confusion/suggestions.
- Auto‑wrap spoiler detection on non‑spoiler fields (warning + move to capsule).

Conversion form (public review)

- Preload beta info; require headline, quick take, tags, rating
- Optional spoiler capsule + route label (abstracted)
- “Verified Purchase” if account owns product post‑launch


## 8) Metrics and Admin Views

Dashboards

- Applications: totals, completion rate, geographic/timezone distribution
- Scoring: histogram of total scores; top/bottom quartiles
- Cohort composition: device mix, timezone coverage, experience levels
- Engagement: open/download events, completion %, feedback submitted %
- Review conversion: % converted within 24/48/72h of launch

Queues

- NDA pending >48h → reminder → auto‑expire after [X] days
- Feedback missing at T−24h → urgent reminder
- Conversion missing at T+24h → reminder → mark strike at T+72h


## 9) Anti‑Leak Measures (operational)

- Watermarked files with purchaser ID and order/application reference.
- Device/account logging for access events.
- Portal‑only chapters for sensitive content.
- Anomaly detection: excessive downloads, sharing indicators → auto‑flag.


## 10) Handoff Artifacts

- Scoring spreadsheet (ready to use)
    - Tabs: Raw Applications, Scoring (auto weights), Rank, Cohort Builder, Waitlist
- Email templates (TXT/HTML)
- Form specs (JSON/YAML or doc) for CMS/portal integration
- SOP one‑pagers
    - “Run a Beta Cycle”
    - “Score and Select Cohort”
    - “Handle Reminders and Conversions”
    - “Respond to Breaches/Revocations”

If any field, weight, or quota should be tuned (e.g., increase first‑time reader quota to 40%, or adjust Depth weight), say the word and I’ll revise the kit before packaging the files.

<div style="text-align: center">⁂</div>

[^15_1]: 8.-Excellent-moving-into-deliverables-production.md

[^15_2]: 1.-Website-Blueprint-for-the-Novel-Series.md

[^15_3]: 2.-Where-We-Begin.md

[^15_4]: 3.-locking-initial-decisions-and-moving-forward.md

[^15_5]: 4.-Locked-Decisions-What-Happens-Next2.md

[^15_6]: 5.-setting-up-contact-age-guidance-and-next-deliverables.md

[^15_7]: 6.-proceeding-with-deliverables.md

[^15_8]: 7.-Acknowledged-proceeding-with-deliverables.md

[^15_9]: 10.-Next-Steps.md

[^15_10]: 9.-Project-Status-Review.md


---

# Content Inventory Templates (Seeded, Paste‑Ready)

Below are the six spreadsheet schemas with seeded example rows. Each sheet is designed to support spoiler controls, ownership/progress gating, and cross‑linking across the site. Copy into a spreadsheet tool (one tab per section). Field lists come first, then 3–6 sample rows to validate workflows.

## 1) Works \& Editions

Fields

- WorkID (slug)
- Season
- IssueNumber
- Title
- Edition (Standard|Deluxe|Bundle)
- Formats (EPUB|PDF|MOBI)
- PreorderMonth (placeholder “[Month, Year]”)
- ReleaseDate (YYYY‑MM‑DD or blank)
- DeluxeExtras (comma‑sep; e.g., “annotations, concept art”)
- ContentWarnings (editable text)
- AgeGuidance (“13+ recommended” by default)
- DownloadLimit (default 5)
- WatermarkNote (Y/N; note shown)
- ProductPageCopy (short, non‑spoiler overview)
- StoreTags (comma‑sep)

Seeded rows

- S1‑I1‑STD | Season1 | 1 | The Veiled City | Standard | EPUB,PDF,MOBI | [Month, Year] |  |  | “violence; dark themes” | 13+ recommended | 5 | Y | “Entry point into the conflict surrounding the City’s hidden accords.” | “season1,issue1”
- S1‑I1‑DLX | Season1 | 1 | The Veiled City | Deluxe | EPUB,PDF,MOBI | [Month, Year] |  | “annotations, concept art” | “violence; dark themes” | 13+ recommended | 5 | Y | “Includes author annotations and concept art.” | “season1,issue1,deluxe”
- S1‑B1 | Season1 |  | Season One Bundle | Bundle | EPUB,PDF,MOBI | [Month, Year] |  | “bundle bonus: mini‑artbook PDF” | “violence; dark themes” | 13+ recommended | 5 | Y | “Bundle of Season One issues with extras.” | “season1,bundle”

***

## 2) Characters

Fields

- CharacterID (slug)
- Name (public‑safe)
- FirstAppearanceWorkID
- POV (Y/N)
- ArcTags (comma‑sep)
- SpoilerSeverity (Low|Medium|High)
- OwnershipLocks (WorkIDs that elevate details, comma‑sep)
- CapsuleMinimal (short, non‑spoiler bio)
- CapsuleStandard (reveals canon tied to owned Works)
- CapsuleFull (all canon including branches/endings)
- Relations (CharacterIDs, abstract where needed)
- TimelineLinks (EventIDs, abstracted labels)
- BranchTags (abstract route labels; e.g., “Silent Accord”)

Seeded rows

- CH‑LYRA | Lyra | S1‑I1‑STD | Y | “Foundations,City” | Medium | “S1‑I1‑STD,S1‑I1‑DLX” | “An analyst drawn into the City’s fragile balance.” | “Lyra’s first mission tests loyalties as hidden accords surface.” | “Lyra’s choices diverge under Silent Accord vs Iron Vow.” | “CH‑MAREN (ally, early), CH‑ADEM (rival, hinted)” | “EV‑MARKET‑STANDOFF, EV‑HALL‑SUMMIT” | “Silent Accord, Iron Vow”
- CH‑MAREN | Maren | S1‑I1‑STD | N | “Foundations” | Low | “S1‑I1‑STD” | “Logistics lead with a network of favors.” | “Connects Lyra to key intermediaries.” | “Reveals leverage tactics under Veiled Tide.” | “CH‑LYRA (ally), CH‑ADEM (neutral)” | “EV‑MARKET‑STANDOFF” | “Veiled Tide”
- CH‑ADEM | Adem | S1‑I1‑STD | N | “City,Conflict” | High | “S1‑I1‑STD,S1‑I2‑STD” | “A figure operating at the edge of official channels.” | “His alignment varies based on early choices.” | “Ending alignment reveals in Full mode.” | “CH‑LYRA (rival), CH‑MAREN (neutral)” | “EV‑HALL‑SUMMIT” | “Iron Vow, Broken Oath”

***

## 3) Events / Timeline

Fields

- EventID (slug)
- Title (non‑spoiler safe)
- Era (e.g., “Foundations”)
- Date (in‑world, optional)
- Participants (CharacterIDs; abstract or initials if needed)
- OutcomeSummaryMinimal
- OutcomeSummaryStandard
- OutcomeSummaryFull
- SpoilerSeverity (Low|Medium|High)
- OwnershipLocks (WorkIDs)
- BranchTag (abstract route)
- RelatedWorks (WorkIDs)
- RelatedCharacters (CharacterIDs)

Seeded rows

- EV‑MARKET‑STANDOFF | Market Standoff | Foundations | 1.12 | “CH‑LYRA, CH‑MAREN” | “A tense dispute interrupts a routine supply run.” | “The dispute reveals fault lines between factions.” | “Under Silent Accord, a hidden intermediary emerges; Iron Vow escalates.” | Medium | “S1‑I1‑STD” | “Silent Accord, Iron Vow” | “S1‑I1‑STD,S1‑I1‑DLX” | “CH‑LYRA,CH‑MAREN”
- EV‑HALL‑SUMMIT | Hall Summit | Foundations | 1.18 | “CH‑LYRA, CH‑ADEM” | “Leaders convene to review accords.” | “A proposal challenges the status quo.” | “Full reveals branch‑dependent concessions or walk‑outs.” | High | “S1‑I1‑STD,S1‑I2‑STD” | “Veiled Tide” | “S1‑I1‑STD,S1‑I2‑STD” | “CH‑LYRA,CH‑ADEM”

***

## 4) Route Nodes \& Endings

Fields

- NodeID (slug)
- NodeLabelPublic (abstract, non‑spoiler; e.g., “Gatehouse Choice”)
- Arc/Era
- Prerequisites (tags or prior nodes)
- BranchOptions (abstract labels, comma‑sep)
- SpoilerSeverity (Low|Medium|High)
- OwnershipLocks (WorkIDs)
- CapsuleMinimal (vague description)
- CapsuleStandard (owned‑content reveal)
- CapsuleFull (explicit decision dynamics)
- EndingID (if terminal; else blank)
- EndingCategory (e.g., “Reprieve”, “Severance”)
- EndingLabelPublic (abstract)

Seeded rows

- NODE‑GATE | Gatehouse Crossroads | Foundations | “Reached EV‑MARKET‑STANDOFF” | “Silent Accord, Iron Vow” | Medium | “S1‑I1‑STD” | “A choice at the threshold changes how allies respond.” | “Standard reveals who’s impacted if you own Issue1.” | “Full clarifies which path strengthens which faction.” |  |  |
- NODE‑PARLEY | Parley or Pressure | Foundations | “After NODE‑GATE” | “Veiled Tide, Broken Oath” | High | “S1‑I1‑STD,S1‑I2‑STD” | “A negotiation shifts tone.” | “Standard surfaces the cost of pressure.” | “Full names the concession or breach.” | END‑REPRIEVE | “Reprieve” | “Quiet Truce”
- END‑REPRIEVE |  | Foundations | “After NODE‑PARLEY” |  | High | “S1‑I2‑STD” | “An uneasy calm.” | “Standard hints who stands down.” | “Full details the terms and long‑tail effects.” | END‑REPRIEVE | “Reprieve” | “Quiet Truce”

***

## 5) Glossary

Fields

- TermID (slug)
- Term
- DefinitionMinimal (one‑line, non‑spoiler)
- DefinitionStandard (expanded for owners)
- DefinitionFull (complete, including branch‑specific nuances)
- ArcTags
- SpoilerSeverity (Low|Medium|High)
- OwnershipLocks (WorkIDs)
- RelatedEntries (Characters/Events/Nodes IDs)

Seeded rows

- GL‑ACCORDS | Accords | “Framework of understandings that keeps the City steady.” | “Agreements vary by faction; enforcement is informal.” | “Branch‑specific concessions emerge under Veiled Tide.” | “Foundations,City” | Medium | “S1‑I1‑STD” | “EV‑HALL‑SUMMIT,CH‑LYRA”
- GL‑TIDE | Veiled Tide | “A maneuvering strategy that favors leverage over force.” | “Used by intermediaries to ‘nudge’ outcomes.” | “In Full, ties to specific concessions at the Summit.” | “Foundations” | High | “S1‑I1‑STD,S1‑I2‑STD” | “EV‑HALL‑SUMMIT,NODE‑PARLEY”

***

## 6) Reviews

Fields

- ReviewID
- WorkID
- Edition (Standard|Deluxe|Bundle)
- ReviewerType (Beta|Public)
- VerifiedPurchase (Y/N)
- Headline
- QuickTake (1–2 sentences)
- Tags (choose 2–3: pacing, character, worldbuilding, clarity, emotional impact)
- Rating (1–5)
- SpoilerCapsule (text; optional)
- RouteLabel (abstract; optional)
- EndingType (abstract tag; optional, hidden unless Full or owner)
- HelpfulCount
- ReportFlags (spoilers|abuse|off‑topic)
- Status (Pending|Published|Rejected)
- SubmittedAt (UTC)

Seeded rows

- RV‑BETA‑001 | S1‑I1‑STD | Standard | Beta | N | “Atmospheric and tense” | “The City feels alive; the tension builds without cheap tricks.” | “pacing,worldbuilding” | 4 |  | “Silent Accord” |  | 5 | 0 | Published | 2025‑06‑01T12:00:00Z
- RV‑BETA‑002 | S1‑I1‑DLX | Deluxe | Beta | N | “Annotations add depth” | “The author notes clarified motives I missed.” | “clarity,character” | 5 | “A mid‑chapter reveal [spoiler capsule].” | “Iron Vow” | “Reprieve” | 2 | 0 | Published | 2025‑06‑02T09:00:00Z
- RV‑PUB‑001 | S1‑I1‑STD | Standard | Public | Y | “Hooked from chapter 2” | “Great momentum and layered politics.” | “pacing,worldbuilding” | 5 |  |  |  | 0 | 0 | Pending | 2025‑[TBD]

***

## Usage Notes

- SpoilerSeverity drives capsule behavior; OwnershipLocks define when Standard content appears by default.
- Abstract route labels avoid raw spoilers: “Silent Accord, Iron Vow, Veiled Tide, Broken Oath” (placeholders; rename later).
- First pass content should prioritize Minimal capsules to keep navigation safe for new readers.
- For QA, preview entries in Minimal/Standard/Full before publish; fix any leakage flagged by “spoiler lint.”
- Keep IDs stable; titles and copy can iterate without breaking cross‑links.

If CSVs are preferred, say the word and I’ll output each sheet as CSV with these headers and sample rows.

<div style="text-align: center">⁂</div>

[^16_1]: 8.-Excellent-moving-into-deliverables-production.md

[^16_2]: 1.-Website-Blueprint-for-the-Novel-Series.md

[^16_3]: 2.-Where-We-Begin.md

[^16_4]: 3.-locking-initial-decisions-and-moving-forward.md

[^16_5]: 4.-Locked-Decisions-What-Happens-Next2.md

[^16_6]: 5.-setting-up-contact-age-guidance-and-next-deliverables.md

[^16_7]: 6.-proceeding-with-deliverables.md

[^16_8]: 7.-Acknowledged-proceeding-with-deliverables.md

[^16_9]: 10.-Next-Steps.md

[^16_10]: 9.-Project-Status-Review.md


---

# Admin SOP Checklists + Microcopy Bundle (Paste‑Ready)

Below are concise, step‑by‑step SOPs for the four admin workflows, followed by the microcopy bundle for consistent UI/UX language across the site. Everything is tailored to the current decisions: watermarking for beta, 5‑download limit, spoiler modes, and the “Beta Average Score” module.

## Admin SOP Checklists

### 1) New Issue Release

Pre‑release (T−14 to T−1 days)

- Create Products
    - Create Standard and Deluxe editions.
    - Set Formats: EPUB, PDF, MOBI.
    - Set PreorderMonth placeholder; add ReleaseDate when finalized.
    - Set price, regions (no exclusions), taxes, coupons (if any).
- Upload Assets
    - Upload files; enable watermark note if applicable.
    - Record file sizes for Tech Specs.
- Product Page Copy
    - Paste short non‑spoiler overview.
    - Add Age Guidance (13+ recommended).
    - Add Content Warnings (editable set).
    - Add license bullets and 5‑download note.
- Beta Snapshot (if pre‑release)
    - Enable “Beta Average Score” module.
    - Confirm sample size “n” displays and has “Beta” label.
    - Set tooltip copy.
- Store Linking
    - Link bundle/season pages as needed.
    - Add preorder badge and countdown.
- Announcements
    - Draft Release Post (non‑spoiler).
    - Prepare newsletter segment and scheduling.
    - Prepare social copy (optional).
- QA
    - Verify pricing currencies and tax display.
    - Test page in guest vs logged‑in vs owner states.

Release day (T0)

- Switch preorder → release state (auto or manual).
- Verify purchase and download flows.
- Send release newsletter; publish Release Post.
- Monitor error logs and support inbox for the first 24h.

Post‑release (T+1 to T+7)

- Switch Reviews module to Public Average default.
- Keep “Beta Snapshot” tab accessible for transparency.
- Review early public reviews; moderate as needed.

***

### 2) Beta Cycle

Planning (T−21 to T−7)

- Set cohort target (40–60), dates for reading/review windows (2+1 weeks).
- Prepare application form and excerpt for feedback task.
- Confirm scoring weights and tie‑breakers.
- Prepare email templates (acceptance, waitlist, reminders, revocation, launch‑day conversion).

Applications (T−7 to T−1)

- Open applications; monitor completion rate.
- Close applications; export to scoring sheet.
- Apply automated scoring and rank.
- Enforce cohort quotas (device/timezone/experience).
- Build final cohort and waitlist.

Onboarding (T0 to T+2)

- Send Acceptance/Waitlist emails.
- Collect NDA e‑signatures; auto‑expire if not signed by deadline.
- Provision access:
    - Watermarked downloads.
    - Portal‑only chapters for sensitive drops.

Reading window (T+0 to T+14)

- Send mid‑window reading reminder.
- Monitor anomalies (excessive downloads, sharing indicators).

Review window (T+14 to T+21)

- Open feedback forms; send opening reminder.
- Send 48h‑left reminder.
- Track submissions; triage support issues.

Wrap‑up (T+21 to Launch)

- Compile feedback themes and completion metrics.
- Mark non‑compliant users (one strike → waitlist next cycle).
- Prepare launch‑day conversion campaign.

Launch day

- Send “Convert your beta review to public” email.
- Track conversion % at 24/48/72h; send nudges as needed.

***

### 3) Spoiler QA

Content authoring

- Tag each entry with: Arc, Issue, POV, Branch, Ending‑level, Era, SpoilerSeverity (L/M/H).
- Set OwnershipLocks (WorkIDs) and progress dependencies.

Preview sweeps

- Minimal mode:
    - Ensure only high‑level summaries appear; no late names or outcomes.
- Standard mode:
    - Ensure details reveal only for owned content; no leakage of unreached branches.
- Full mode:
    - Confirm complete canon is visible; route labels and endings appear correctly.

Spoiler lint

- Run automated lint:
    - Flags fields visible beyond allowed mode.
    - Flags cross‑links that would reveal locked content.
- Resolve all warnings; re‑run.

Page spot checks

- Character page with capsules:
    - Verify capsule labels and severity badges.
    - Verify ownership/progress locks and “Mark as finished” effects.
- Event page:
    - Check abstracted participants when locked.
    - Verify outcomes remain in capsules.

Sign‑off

- Log QA pass with date, editor initials, and any known caveats to revisit later.

***

### 4) Review Moderation

Intake and auto‑processing

- Auto‑wrap spoilers detected in non‑spoiler fields.
- Queue reasons: spoilers, abuse/hate, off‑topic/promo, spam.

Moderator actions

- Approve: meets guidelines; spoiler handling correct.
- Edit (light): redact or move a sentence into spoiler capsule; note change.
- Reject: clear policy breach; notify reviewer with brief rationale and link to guidelines.

Sorting and display

- Default sort: Helpful; allow Newest, Highest, Lowest.
- Filters: spoiler‑free only; route label; POV focus; edition.

Badges and labels

- “Verified Purchase” for public reviews when owned.
- “Beta” label on pre‑release reviews; move Beta tab secondary after launch.

Escalation

- Repeat violations → account warning; severe cases → account action per policy.
- Appeals: provide a simple reply channel; review within 7 days.

Reporting and metrics

- Weekly: approvals/rejections, top flags, response SLAs.
- Monthly: trends in ratings, common feedback themes, guideline gaps.

***

## Microcopy Bundle

General/legal

- Copyright footer: “© 2025 Sina Panahi. All rights reserved.”
- License bullets (product page):
    - “Personal‑use license”
    - “5 downloads per format”
    - “Watermarking for security”
    - “Digital‑only refund policy applies”

Age guidance and warnings

- Age guidance (standard): “Recommended for ages 13+ for dark themes and narrative intensity.”
- Content warnings header: “Content Warnings”
- Content warnings default set: “May include: violence, war consequences, psychological manipulation, moral ambiguity.”
- Disclaimer (small): “These warnings may contain mild spoilers.”

Downloads and resets

- Counter label: “Download (2/5 used)”
- Limit note: “Each purchase includes up to 5 downloads per format.”
- Reset prompt: “Need a reset? Email support@zoroasterverse.com (include your Order ID).”
- Watermark note: “Your files may include a purchaser‑specific watermark.”

Spoiler modes

- Global toggle label: “Spoiler Mode”
- Minimal: “High‑level summaries only; major reveals hidden.”
- Standard: “Reveals canon for content in your Library; abstracts unreached branches.”
- Full: “Shows all canon, including branches and endings.”
- Per‑page override: “Adjust for this page only”

Spoiler capsules

- Capsule button: “Tap to reveal”
- Capsule lead‑in (example): “Reveals Branch: Silent Accord — tap to reveal”
- Lock hint: “Unlocks after you finish: [Issue/Season]”
- Severity badges: “Low”, “Medium”, “High”

Beta program

- Beta badge (reviews): “Beta”
- Beta Score module title: “Beta Average Score”
- Beta Score tooltip: “Based on early beta feedback; may differ from public reviews.”
- Conversion nudge (launch‑day page banner): “Were you in the beta? Convert your review to public now.”

Reviews

- Form labels:
    - “Headline (max 80 characters)”
    - “Quick take (1–2 sentences)”
    - “Highlights (choose 2–3)”
    - “Rating (1–5)”
    - “Major Moments (spoiler capsule)”
    - “Route label (abstracted)”
- Auto‑wrap warning: “We found potential spoilers. Move them into the spoiler section?”
- Verified badge: “Verified Purchase”
- Empty state (no reviews yet): “Be the first to review this issue.”

Preorder and release

- Preorder badge: “Preorder: [Month, Year]”
- Release badge: “Available Now”
- Countdown label: “Releases in: [DD]d [HH]h”

Support and contact

- Footer contact: “Questions? Email support@zoroasterverse.com”
- Support display name: “Zoroasterverse Support”

***

## Handoff Notes

- Keep microcopy centralized so product and CMS share strings across pages.
- Localize keys early (even if English‑only at launch) to avoid rework later.
- Pair SOPs with checklists in the CMS or project tracker; link each step to its owner and due date.
- Before any publish, run Spoiler QA and Review Moderation SOPs once end‑to‑end with sample content.

If any labels or tone should skew more formal or more casual, specify the preference and I’ll adjust the bundle accordingly.

<div style="text-align: center">⁂</div>

[^17_1]: 8.-Excellent-moving-into-deliverables-production.md

[^17_2]: 1.-Website-Blueprint-for-the-Novel-Series.md

[^17_3]: 2.-Where-We-Begin.md

[^17_4]: 3.-locking-initial-decisions-and-moving-forward.md

[^17_5]: 4.-Locked-Decisions-What-Happens-Next2.md

[^17_6]: 5.-setting-up-contact-age-guidance-and-next-deliverables.md

[^17_7]: 6.-proceeding-with-deliverables.md

[^17_8]: 7.-Acknowledged-proceeding-with-deliverables.md

[^17_9]: 10.-Next-Steps.md

[^17_10]: 9.-Project-Status-Review.md

