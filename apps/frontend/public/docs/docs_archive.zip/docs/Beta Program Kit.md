# Next: Beta Program Kit

Confirmed. The next deliverable is the full Beta Program Kit. Below is the complete, paste‑ready spec you can review and edit. Once approved, I’ll package the email templates and scoring sheets as files.

## 1) Application Spec (fields, validation, storage)

Sections and fields

- Basics
    
    - Full name (required, text)
        
    - Email (required, email format, unique)
        
    - Country/Timezone (required, select)
        
    - Reading speed (required, select: <2h/wk, 2–4h/wk, 5–7h/wk, 8h+)
        
- Experience
    
    - Prior beta experience (optional, multi-line text; encourage links/titles)
        
    - Favorite genres (required, multi-select)
        
    - Strengths (required, multi-select: plot, pacing, character, continuity, clarity, worldbuilding)
        
- Availability & Devices
    
    - Weekly availability during window (required, select: 2–3h, 4–6h, 7–10h, 10h+)
        
    - Preferred formats (required, multi-select: EPUB, PDF)
        
    - Primary device (optional, select: eReader, tablet, phone, desktop)
        
- Sample Feedback Task
    
    - Prompt: “Read this short excerpt (≈700–900 words). Answer 3 questions.”
        
    - Q1: What worked best and why? (required, 100–300 words)
        
    - Q2: What confused you and how would you clarify it? (required, 100–300 words)
        
    - Q3: One actionable suggestion (required, 60–200 words)
        
- Consents
    
    - I consent to watermarked files (required, checkbox)
        
    - I agree to sign the NDA if selected (required, checkbox)
        
    - Optional: share device logs for QA (optional, checkbox)
        

Validation

- Required fields enforced per section before continuing.
    
- Word-count hints/warnings for sample answers.
    
- Email uniqueness check; rate limit submissions.
    

Storage

- Persist as Application entity with fields:
    
    - basics, experience, availability, devices, sample_feedback, consents, timestamps, status (submitted/shortlisted/accepted/waitlist/rejected).
        

## 2) Scoring Rubric and Weights

Criteria (0–5 each, before weights)

- Analytical Depth: specificity, evidence, and clarity of reasoning in sample feedback.
    
- Reliability & Availability: stated availability fit for the window; prior track record if provided.
    
- Communication Tone: respectful, constructive, actionable phrasing.
    
- Genre Fit: familiarity with branching narratives, multi‑POV tolerance.
    
- Diversity Mix: contributes to cohort diversity (device types, timezone spread, experience levels).
    

Weights

- Analytical Depth ×1.5
    
- Reliability & Availability ×1.25
    
- Genre Fit ×1.25
    
- Tone ×1.0
    
- Diversity Mix ×1.0
    

Computation

- Normalize raw 0–5 to weighted score; total score = sum(weighted).
    
- Auto-rank descending.
    

Review aids

- Depth quick rubric:
    
    - 5: Specific examples + explains why + actionable fix
        
    - 3: General points + some reasons
        
    - 1: Vague sentiment, no evidence
        
- Tone quick rubric:
    
    - 5: Respectful, objective, actionable
        
    - 3: Neutral but light on solutions
        
    - 1: Dismissive or harsh
        

## 3) Cohort-Balancing Rules and Tie‑Breakers

Cohort target

- Size: 40–60.
    
- Device mix: aim ≥25% each for EPUB‑on‑eReader and PDF‑on‑tablet/desktop; allow flexible ranges.
    
- Timezones: cover Americas, Europe/Africa, Asia/Oceania; aim for at least 25% each where possible.
    
- Experience: ≥30% first‑time beta readers; ≥30% experienced.
    
- Formats: ensure both EPUB and PDF are represented.
    

Selection flow

- Step 1: Filter incomplete/non-consent applications.
    
- Step 2: Compute weighted total score; create ranked list.
    
- Step 3: Iteratively fill cohort while enforcing device/timezone/experience quotas.
    
- Step 4: Tie‑breakers in order:
    
    - Higher Analytical Depth
        
    - Higher Reliability & Availability
        
    - Improves timezone/device diversity
        
    - Earlier submission time (as last resort)
        
- Step 5: Build waitlist (top 20–30% after cutoff) preserving diversity.
    

Backfill

- If a selected reader drops or misses NDA deadline, invite next on waitlist matching the quota deficit (e.g., fill EPUB/eReader gap).
    

## 4) Participation Rules (concise, enforceable)

- Deliverables
    
    - Submit structured feedback by the stated deadline via the portal form.
        
    - On launch day, convert beta review to a public review (spoiler‑free or spoiler‑tagged).
        
- Conduct
    
    - Respectful communication; follow spoiler rules; no leaks or sharing.
        
    - Use assigned channels for feedback and issue reporting.
        
- Enforcement
    
    - One strike (missed deadline or no review conversion) → waitlist for next cycle.
        
    - NDA or policy breach → immediate revocation; possible permanent removal.
        

## 5) Operational Timeline (per issue)

- Day 0: Applications close → scoring and shortlist (48–72h).
    
- Day 2–3: Send acceptance/waitlist emails → NDA e‑sign.
    
- Day 5: Beta drop opens (watermarked files + portal-only for sensitive content).
    
- Day 5–19: Reading window (2 weeks) → mid‑window reminder.
    
- Day 19–26: Review window (1 week) → 2 reminders (opening + 48h before close).
    
- Launch Day: Trigger “convert to public review” email; verify conversions in 24–48h.
    

## 6) Email Templates (paste‑ready)

Acceptance (Subject: Welcome to the Zoroasterverse Beta — You’re In)

- Hi [First Name],
    
    - You’ve been selected for the upcoming beta cohort (Window: [Dates], Timezone: [TZ]).
        
    - What’s next:
        
        - Sign the NDA here: [link]
            
        - Access opens: [date/time]
            
        - Reading window: [date]–[date]
            
        - Feedback due: [deadline date/time]
            
    - Format access: EPUB/PDF (watermarked), portal‑only for sensitive drops.
        
    - Reminders will be sent mid‑window and 48h before deadline.
        
    - Questions? [beta@zoroasterverse.com](mailto:beta@zoroasterverse.com) or [support@zoroasterverse.com](mailto:support@zoroasterverse.com)
        
    - Thank you, and welcome aboard.
        
- Zoroasterverse Beta Team
    

Waitlist (Subject: Zoroasterverse Beta — Waitlist Status)

- Hi [First Name],
    
    - Thank you for applying. The current cohort is full; you’ve been placed on the waitlist.
        
    - We’ll reach out if a spot opens or in future cycles.
        
    - We appreciate your interest and hope to read with you soon.
        
- Zoroasterverse Beta Team
    

Reminder — Mid‑Window Reading (Subject: Beta Check‑In — How’s the Read Going?)

- Hi [First Name],
    
    - Quick check‑in. Reading continues through [date]. Feedback is due by [deadline].
        
    - If anything blocks progress (format/device issues), reply to this email.
        
- Beta Team
    

Reminder — 48h Before Feedback Due (Subject: 48 Hours Left — Feedback Due [deadline])

- Hi [First Name],
    
    - A quick reminder that feedback is due in 48 hours: [deadline date/time, TZ].
        
    - Submit here: [portal link]
        
    - Thanks for keeping us on schedule!
        
- Beta Team
    

Revocation (Subject: Beta Access Revoked — Policy/NDA Breach)

- Hi [First Name],
    
    - Your beta access has been revoked due to a policy/NDA violation: [brief reason].
        
    - This decision may affect eligibility for future cycles.
        
    - If you believe this is an error, reply within 7 days.
        
- Beta Team
    

Launch‑Day Conversion (Subject: It’s Live — Convert Your Beta Review Today)

- Hi [First Name],
    
    - The issue has launched! Please convert your beta review to a public review today to remain eligible for future betas.
        
    - Convert here: [review conversion link]
        
    - Thank you for helping other readers discover the story.
        
- Beta Team
    

## 7) Portal Forms and QA

Feedback form (beta)

- Fields:
    
    - Overall rating (1–5)
        
    - Quick take (1–2 sentences)
        
    - Highlights tags (choose 2–3): pacing, character, worldbuilding, clarity, emotional impact
        
    - Major moments (spoiler capsule)
        
    - Confusion points (text)
        
    - Suggestions (text)
        
    - Device/format used (select)
        
- Validation:
    
    - Required rating, quick take, tags, and at least one of confusion/suggestions.
        
- Auto‑wrap spoiler detection on non‑spoiler fields (warning + move to capsule).
    

Conversion form (public review)

- Preload beta info; require headline, quick take, tags, rating
    
- Optional spoiler capsule + route label (abstracted)
    
- “Verified Purchase” if account owns product post‑launch
    

## 8) Metrics and Admin Views

Dashboards

- Applications: totals, completion rate, geographic/timezone distribution
    
- Scoring: histogram of total scores; top/bottom quartiles
    
- Cohort composition: device mix, timezone coverage, experience levels
    
- Engagement: open/download events, completion %, feedback submitted %
    
- Review conversion: % converted within 24/48/72h of launch
    

Queues

- NDA pending >48h → reminder → auto‑expire after [X] days
    
- Feedback missing at T−24h → urgent reminder
    
- Conversion missing at T+24h → reminder → mark strike at T+72h
    

## 9) Anti‑Leak Measures (operational)

- Watermarked files with purchaser ID and order/application reference.
    
- Device/account logging for access events.
    
- Portal‑only chapters for sensitive content.
    
- Anomaly detection: excessive downloads, sharing indicators → auto‑flag.
    

## 10) Handoff Artifacts

- Scoring spreadsheet (ready to use)
    
    - Tabs: Raw Applications, Scoring (auto weights), Rank, Cohort Builder, Waitlist
        
- Email templates (TXT/HTML)
    
- Form specs (JSON/YAML or doc) for CMS/portal integration
    
- SOP one‑pagers
    
    - “Run a Beta Cycle”
        
    - “Score and Select Cohort”
        
    - “Handle Reminders and Conversions”
        
    - “Respond to Breaches/Revocations”
        

If any field, weight, or quota should be tuned (e.g., increase first‑time reader quota to 40%, or adjust Depth weight), say the word and I’ll revise the kit before packaging the files.

1. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/fa582a84-9b3e-40f5-b605-c08256d0d91f/8.-Excellent-moving-into-deliverables-production.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/fa582a84-9b3e-40f5-b605-c08256d0d91f/8.-Excellent-moving-into-deliverables-production.md)
2. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/1523de6f-0923-4bb6-82cb-ef7a201734b5/1.-Website-Blueprint-for-the-Novel-Series.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/1523de6f-0923-4bb6-82cb-ef7a201734b5/1.-Website-Blueprint-for-the-Novel-Series.md)
3. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/ab12b3d0-2a37-495b-a985-272edd9c2daa/2.-Where-We-Begin.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/ab12b3d0-2a37-495b-a985-272edd9c2daa/2.-Where-We-Begin.md)
4. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/4bc45b88-939c-4d28-b9cb-5fdd68dfe776/3.-locking-initial-decisions-and-moving-forward.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/4bc45b88-939c-4d28-b9cb-5fdd68dfe776/3.-locking-initial-decisions-and-moving-forward.md)
5. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f26d2a14-77e8-4e66-a6fd-6b74409ea4f5/4.-Locked-Decisions-What-Happens-Next2.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f26d2a14-77e8-4e66-a6fd-6b74409ea4f5/4.-Locked-Decisions-What-Happens-Next2.md)
6. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/e0a0c421-7424-4215-879a-173898b48e33/5.-setting-up-contact-age-guidance-and-next-deliverables.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/e0a0c421-7424-4215-879a-173898b48e33/5.-setting-up-contact-age-guidance-and-next-deliverables.md)
7. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f5e37101-957e-4b69-987b-1ac000dfac8e/6.-proceeding-with-deliverables.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f5e37101-957e-4b69-987b-1ac000dfac8e/6.-proceeding-with-deliverables.md)
8. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/325d0e74-6a48-4cbb-8963-c84b94c5cc90/7.-Acknowledged-proceeding-with-deliverables.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/325d0e74-6a48-4cbb-8963-c84b94c5cc90/7.-Acknowledged-proceeding-with-deliverables.md)
9. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/73989437-cf00-4de9-b15f-28f1b138d6d3/10.-Next-Steps.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/73989437-cf00-4de9-b15f-28f1b138d6d3/10.-Next-Steps.md)
10. [https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/819cf394-c023-4705-8aad-26ea853640ad/9.-Project-Status-Review.md](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/819cf394-c023-4705-8aad-26ea853640ad/9.-Project-Status-Review.md)