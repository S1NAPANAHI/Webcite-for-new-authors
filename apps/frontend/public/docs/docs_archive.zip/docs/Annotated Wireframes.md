# Annotated Wireframes — Structure, Key Components, and Copy

Below are detailed, no-code wireframe specifications for each screen: layout structure, component behavior, data bindings, and paste-ready microcopy. These are ready for drawing into PDF/images or direct translation into a design tool.

## 1) Product Page

### A. Hero Section
- Elements:
  - Cover image (left on desktop; top on mobile)
  - Title, Issue/Season label
  - Edition selector (Standard/Deluxe)
  - Preorder badge (if applicable): “Preorder: [Month, Year]”
- Notes:
  - On release, Preorder badge auto-switches to “Available Now.”
  - Deluxe shows extras list (annotations, concept art, soundtrack links) under selector.

### B. Purchase Module
- Price display per edition
- CTA:
  - If preorder: “Preorder Now”
  - If released: “Buy Issue”
  - If owned: “Add to Library” switches to “In Library”
- Formats checklist:
  - EPUB, PDF, MOBI
  - License bullet reminder under formats
- Content warnings summary:
  - “Recommended for ages 13+ for dark themes and narrative intensity.”
  - “May include: violence, war consequences, psychological manipulation, moral ambiguity.”

Microcopy:
- License bullets:
  - “Personal-use license”
  - “5 downloads per format”
  - “Watermarking for security”
  - “Digital-only refund policy applies”
- Tooltip on downloads:
  - “Each purchase includes up to 5 downloads per format; resets via support.”

### C. Beta Average Score Module (Pre-Release)
- Badge: “Beta Average Score”
- Score display: “4.2/5” + “n=47 (Beta)”
- Tooltip: “Based on early beta feedback; may differ from public reviews.”
- Note:
  - Place near purchase module for visibility.
  - Collapsible details: “What counts as ‘Fresh’?” → “Ratings ≥4/5 count as ‘Fresh’.”

### D. Details Section
- Tabs: Overview | Editions | Extras (Deluxe only) | Tech Specs (formats, file sizes)
- Overview:
  - Short synopsis (non-spoiler)
  - Reading order link to Series Guide
- Tech Specs:
  - Formats, file size per format, download note, recommended readers/apps

### E. Reviews Section
- Pre-release:
  - “Beta Snapshot” tab first
  - Individual beta reviews labeled “Beta”
  - Filters: spoiler-free only; route label; POV focus; edition
- Post-release:
  - “Public Reviews” tab first
  - Aggregates: Public Average; Fresh ratio badge (optional toggle later)
- Sort: Helpful, Newest, Highest, Lowest
- Card content:
  - Headline, quick take, tags, rating, spoiler capsule (if present), route label (abstracted), edition, Verified Purchase badge (post-release)

### F. Footer Banner (contextual)
- “Have questions? Email support@zoroasterverse.com”

Behavior notes:
- If user is logged in and owns the issue, elevate more detailed non-spoiler copy; do not reveal spoilers.
- Maintain canonical non-spoiler text at Minimal level; deeper details appear only within spoiler capsules across the site.

***

## 2) Library

### A. Library Header
- Title: “Your Library”
- Subnav chips: All | Issues | Bundles | Deluxe | Downloads
- Info banner (dismissible):
  - “Files may include a purchaser-specific watermark. Download limits: 5 per format.”

### B. Item Cards (per owned product)
- Left: cover thumbnail
- Center:
  - Title + Edition tag
  - Formats with counters:
    - EPUB: “Download (2/5 used)”
    - PDF: “Download (0/5 used)”
    - MOBI: “Download (5/5 used)”
- Right:
  - “Mark as finished” toggle
  - “Need a reset? Email support@zoroasterverse.com”

Microcopy:
- Under counters: “Problems downloading? Check your reader app supports EPUB/PDF/MOBI.”
- Reset request hint: “Include your Order ID.”

Behavior notes:
- “Mark as finished” updates site-wide spoiler unlocks (ownership/progress gating).
- Counters decrement on successful download events; show spinner and success/failure states.

***

## 3) Character Page (Spoiler-Aware)

### A. Header + Controls
- Character name (non-spoiler-safe)
- Global spoiler toggle (header-level): Minimal | Standard | Full
- Per-page override toggle: “Adjust for this page only”

Tooltips:
- Minimal: “High-level summaries only; major reveals hidden.”
- Standard: “Reveals canon for content in your Library; abstracts unreached branches.”
- Full: “Shows all canon, including branches and endings.”

### B. Non-Spoiler Overview
- Short bio that avoids late-appearance details and route outcomes
- Tags row (non-spoiler): Arc, Issue of first appearance (abstracted if needed), POV status (Y/N)

### C. Spoiler Capsules
- Sections: History, Relationships, Key Moments, Appearances Timeline
- Capsule design:
  - Label example: “Reveals Branch: Silent Accord — tap to reveal”
  - Severity badge: L/M/H
  - Ownership/progress lock indicator if user hasn’t finished related content
- Inside capsule:
  - Rich text explaining the event/relationship/change
  - Cross-links to related Events and Factions (respecting current spoiler mode)

Behavior notes:
- If user toggles Full mode, display route labels (abstracted) and ending tags where applicable.
- Capsule warns on reveal: “Contains spoilers tied to Issue X.”

***

## 4) Event Page (Spoiler-Aware)

### A. Header + Metadata
- Event title (non-spoiler naming)
- Era/Date, Participants (abstracted if hidden), Location

### B. Summary (Minimal-safe)
- One-paragraph non-spoiler summary

### C. Spoiler Capsules
- Outcome capsule:
  - Label: “Reveals outcome for Branch: Iron Vow — tap to reveal”
  - Severity badge
- Timeline placement snippet (with gate as needed)

Behavior notes:
- If user owns and marked-finished related Issue/Season, elevate to Standard details.
- Cross-links to Character and Route Nodes gated by current mode.

***

## 5) Beta Application → NDA Flow

### A. Application Form (Stepper UI)
- Step 1: Basics
  - Name, Email, Country/Timezone, Reading speed estimate
- Step 2: Experience
  - Past beta reading (titles/links), Genres, Strengths (plot, pacing, character, continuity)
- Step 3: Availability & Devices
  - Weekly hours during window, Device formats (EPUB/PDF)
- Step 4: Sample Feedback Task
  - Short excerpt + 3 guided questions (free-text)
- Step 5: Consents
  - Consent to watermarking
  - Agreement to sign NDA if selected

Validation:
- Required fields for each step; disabled “Next” until complete
- Auto-save on step change

Microcopy:
- “Strong applications are specific and cite examples.”
- “Watermarked files are for your eyes only; leaks result in immediate revocation.”

### B. Post-Application States
- Confirmation screen: “Thanks! We’ll notify you by email.”
- Acceptance email (template-ready): includes cohort window, deadlines, link to NDA
- Waitlist email
- Reminder emails: Week 1 reading; Review week

### C. NDA E‑Sign Checkpoint
- Inline summary:
  - Confidentiality scope, no sharing, watermarking, revocation policy
- Actions:
  - “View Full NDA” (modal)
  - “Sign & Continue”
- Success:
  - “Access granted” screen with “Start Reading” and “Feedback Due” dates

***

## 6) Review Submission + Public Listing

### A. Submission Form (owned users and beta readers)
- Template selector:
  - Spoiler-free
  - Spoiler-tagged
- Common fields:
  - Headline (max 80)
  - Quick take (1–2 sentences)
  - Tags (choose 2–3): pacing, character, worldbuilding, clarity, emotional impact
  - Rating (1–5)
- Spoiler-tagged extras:
  - “Major Moments” inside spoiler capsule
  - Route label (abstracted picker)
  - Ending type (hidden unless Full mode or owner)

Auto-wrap:
- If system detects spoilers in spoiler-free fields, show non-blocking warning: “We found potential spoilers. Move them into the spoiler section?”

### B. Public Listing
- Filters:
  - Spoiler-free only
  - Route label
  - POV focus
  - Edition (standard/deluxe)
- Sort:
  - Helpful, Newest, Highest, Lowest
- Aggregates:
  - Pre-release: “Beta Average Score (n=XX, Beta)”
  - Post-release: “Public Average” + optional “Fresh ratio”

Card layout:
- Headline, quick take, tags, rating stars
- If spoiler content: collapsed capsule with “Tap to reveal”
- Metadata: route label (abstracted), edition, Verified Purchase flag (post-release)

Moderation cues:
- Queue flags: spoilers, abuse, off-topic
- Inline status for reviewer: “Awaiting moderation,” “Published,” or “Updated after moderation”

***

# Cross-Screen Components and Behaviors

- Global spoiler toggle persists in header with last-used mode per session.
- Ownership/progress gating:
  - “Mark as finished” in Library triggers wider unlocks.
  - Capsules respect both ownership and finished state.
- Watermark note:
  - Displayed in Library and on download confirmation/receipt UX.

# Copy Snippets (Ready to Paste)

- Beta Score tooltip: “Based on early beta feedback; may differ from public reviews.”
- Download counter note: “Each purchase includes up to 5 downloads per format.”
- Reset prompt: “Need a reset? Email support@zoroasterverse.com (include your Order ID).”
- Spoiler mode labels:
  - Minimal: “High-level summaries only; major reveals hidden.”
  - Standard: “Reveals canon for content in your Library; abstracts unreached branches.”
  - Full: “Shows all canon, including branches and endings.”

# Handoff Checklist for Design

- Use these sections as artboards: Product, Library, Character, Event, Beta Application, NDA checkpoint, Review Submission, Review Listing.
- Annotate each component with:
  - State variants (preorder vs release; owned vs not; Minimal/Standard/Full)
  - Error/empty/loading states (e.g., downloads exhausted; no reviews)
  - Tooltip/capsule texts from above
- Export as PDF/images for review; keep copy layers editable.

If preferred, I can convert these into a Figma-ready structure outline next or provide low‑fidelity sketches with numbered annotations.

[1] https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/fa582a84-9b3e-40f5-b605-c08256d0d91f/8.-Excellent-moving-into-deliverables-production.md
[2] https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/1523de6f-0923-4bb6-82cb-ef7a201734b5/1.-Website-Blueprint-for-the-Novel-Series.md
[3] https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/ab12b3d0-2a37-495b-a985-272edd9c2daa/2.-Where-We-Begin.md
[4] https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/4bc45b88-939c-4d28-b9cb-5fdd68dfe776/3.-locking-initial-decisions-and-moving-forward.md
[5] https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f26d2a14-77e8-4e66-a6fd-6b74409ea4f5/4.-Locked-Decisions-What-Happens-Next2.md
[6] https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/e0a0c421-7424-4215-879a-173898b48e33/5.-setting-up-contact-age-guidance-and-next-deliverables.md
[7] https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/f5e37101-957e-4b69-987b-1ac000dfac8e/6.-proceeding-with-deliverables.md
[8] https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/325d0e74-6a48-4cbb-8963-c84b94c5cc90/7.-Acknowledged-proceeding-with-deliverables.md
[9] https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/73989437-cf00-4de9-b15f-28f1b138d6d3/10.-Next-Steps.md
[10] https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/44811398/819cf394-c023-4705-8aad-26ea853640ad/9.-Project-Status-Review.md